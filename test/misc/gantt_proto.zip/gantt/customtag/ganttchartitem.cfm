<cfsilent>
<!---:: 
Application: CFI Gantt Chart
File: ganttchartitem.cfm
Author: Simon Horwith
Purpose: Adds items to a CSV Gantt chart
Dependencies:
	CSV Plug-in for viewing
	ganttchart base tag
History:
26-8-04 : prototype created


Attributes:
	Attribute				Required			Description
	from				 	   yes					item from date
	to					  	 	 yes				  item to date
	height			 		    no					height of bar in pixels - default is 10
	borderWidth			    no					 thickness of border in px - default is 0
	borderColour		    no					 border color - default is red - allowed is any named or rgb SVG colour
	borderOpacity		   no					transparency of border as a decimal number - 1 is visible and 0 is invisible - default is 0
	backgroundColour	no					 background colour - default is red - allowed is any named or rgb SVG colour
	backgroundOpacity	no					transparency of background as a decimal number - 1 is visible and 0 is invisible - default is 1
	x							  no				   starting x coordinate - default is 25
	y							  no				   starting y coordinate - default is 30
	rx							  no				   corner x rounding coordinate, 0 is square - default is 10
	ry							  no				   corner y rounding coordinate, 0 is square - default is 10
	label						no					 label to show - default is ""
	labelX					   no					X coordinate to show label from
	
Other Notes:

 ::--->
 
 <!---:: ensure that the tag does not have an end tag ::--->
 <cfif thisTag.hasEndTag>
 	<cfthrow type="Gantt" message="End tag not allowed" detail="The ganttchartitem custom tag does not accept an end tag">
 </cfif>

</cfsilent>


<!---:: define output here ::--->
	<cfoutput>
		<cfswitch expression="#attributes.shape#">
			<cfcase value="rect">
		<rect x="#attributes.x#" y="#attributes.y#" rx="#attributes.rx#" ry="#attributes.ry#" width="#attributes.width#" height="#attributes.height#"
style="fill:#attributes.backgroundColour#;stroke:#attributes.borderColour#;stroke-width:#attributes.borderWidth#;fill-opacity:#attributes.backgroundOpacity#;stroke-opacity:#attributes.borderOpacity#"/>
			</cfcase>
			<cfcase value="triangle">
			<cfscript>
				xOffSet = attributes.width / 2;
				aPoints = arrayNew(1);
				// bottom left
				aPoints[1] = attributes.x - variables.xOffSet & "," & attributes.y + attributes.height;
				// bottom right
				aPoints[2] = attributes.x + variables.xOffSet & "," & attributes.y + attributes.height;
				// top
				aPoints[3] = attributes.x & "," & attributes.y;
				polyPoints = variables.aPoints[1] & " " &  variables.aPoints[2] & " " &  variables.aPoints[3];
			</cfscript>
		<polygon points="#variables.polyPoints#" 
		style="fill:#attributes.backgroundColour#;stroke:#attributes.borderColour#;stroke-width:#attributes.borderWidth#;fill-opacity:#attributes.backgroundOpacity#;stroke-opacity:#attributes.borderOpacity#;"/>
			</cfcase>
			<cfcase value="circle">
				<cfscript>
					radius = attributes.width / 2;
					aPoints = arrayNew(1);
					// center x
					aPoints[1] = attributes.x;
					// center y
					aPoints[2] = attributes.y + variables.radius;
				</cfscript>
				<circle cx="#variables.aPoints[1]#" cy="#variables.aPoints[2]#" r="#variables.radius#"
				style="fill:#attributes.backgroundColour#;stroke:#attributes.borderColour#;stroke-width:#attributes.borderWidth#;fill-opacity:#attributes.backgroundOpacity#;stroke-opacity:#attributes.borderOpacity#;"
				/>
			</cfcase>
		</cfswitch>
		<cfif attributes.label is not "">
			<cfset labelYPos = attributes.y +  8>
			<text style="fill:black;font-family:#attributes.labelFont#;font-size:#attributes.labelFontSize#" y="#variables.labelYPos#" x="#attributes.labelX#">#attributes.label#</text>
		</cfif>
	</cfoutput>
<!---:: end define output ::--->