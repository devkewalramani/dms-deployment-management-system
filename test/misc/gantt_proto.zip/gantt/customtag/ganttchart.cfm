<!---:: 
Application: CFI Gantt Chart
File: ganttchart.cfm
Author: Simon Horwith
Purpose: Creates a CSV Gantt chart
Dependencies:
	CSV Plug-in for viewing
	ganttchartitem subtags to add items
History:
26-8-04 : prototype created


Attributes:
	Attribute				Required			Description
	from					  yes					item from date
	to						    yes					  item to date
	itemUnits				  no					units of measurement for items - default is day
	gridUnits				  no					units of measurement for gridlines - default is month	
	width					   no					 chart width in px - default is 500
	height				       no					 chart height in px. if passed, spacing attribute is ignored. - default height is 0 (unrestricted)
	spacing			  		  no				    item vertical spacing in px. If height attribute is passed, spacing attribute is ignored. - default is 10
	itemHeight			     no					   height of each item in px - default is 10
	borderWidth			    no					  thickness of border in px - default is 5
	borderColour		    no					  border color - default is black
	borderOpacity		   no					 transparency of border as a decimal number - 1 is visible and 0 is invisible - default is 1
	backgroundColour	no					  background colour - default is none
	backgroundOpacity	no					 transparency of background as a decimal number - 1 is visible and 0 is invisible - default is 0
	x							  no					starting x coordinate - default is 20
	y							  no					starting y coordinate - default is 20
	rx							  no					corner x rounding coordinate, 0 is square - default is 20
	ry							  no					corner y rounding coordinate, 0 is square - default is 20
	showgrid				  no					show gridlines? Boollean value - default is true
	spreadChildren		   no					 evenly spread children apart? - Boolean - default is true
	unitLength				 yes					how many pixels a grid unit is
	showGridLabels		no						Boolean - show labels above grid? - default is false and true will push chart down 10 pix with labels at y - 10
	gridColour				no						color of gridlines - default is black
	gridWidth				no						width of gridlines - default is 1
	gridOpacity				no						opacity of gridlines - default is 0.25
	gridLabelFont		  no					  font for grid labels - default is Helvettica
	gridLabelColour		 no						 color of label text - default is black
	showItemLabels	   no						Boolean - show item labels? - default is false
	labelX					 no						  x position of labels - default is 20
	showLabelBox		no						Boolean, whether to put a boundry box around labels - default is false
	gridLabelFontSize	no						Font size for grid labels - default is 12
	gridUnitLength		  no					  length of a grid unit - dynamically determined based on width and units of measurement
	title						no						 title above chart - default is "" (none)
	
Other Notes:

 ::--->

 <!---:: ensure that the tag has an end tag ::--->
 <cfif not thisTag.hasEndTag>
 	<cfthrow type="Gantt" message="End tag required" detail="The ganttchart custom tag requires an end tag">
 </cfif>
 
 <!---:: switch for start and end mode ::--->
 <cfswitch expression="#thisTag.executionMode#">
 	<!---:: Start mode ::--->
	<cfcase value="Start">
		<!---:: define output here ::--->
		<cfoutput>
		<svg width="#attributes.width#" height="#attributes.height#">
		<!-- border -->
		<rect x="#attributes.x#" y="#attributes.y#" rx="#attributes.rx#" ry="#attributes.ry#" width="#attributes.width#" height="#attributes.height#"
	style="fill:#attributes.backgroundColour#;stroke:#attributes.borderColour#;stroke-width:#attributes.borderWidth#;fill-opacity:#attributes.backgroundOpacity#;stroke-opacity:#attributes.borderOpacity#"/>
		<!---:: title ::--->
		<cfscript>
			if (attributes.title is not ""){
				if (attributes.showGridLabels){
					titleYPos = attributes.y - 51;
					if (attributes.showLabelBox){
						labelBoxX = attributes.labelX - attributes.borderWidth;
						labelBoxWidth = attributes.x - variables.labelBoxX;
						titleXPos = (attributes.width / 2) + labelBoxWidth;
					} else {
						titleXPos = attributes.width / 2;
					}
				} else {
					titleYpos = attributes.y - 41;
					titleXPos = attributes.width / 2;
				}
			} else {
				titleYPos = 0;
				titleXPos = 0;
			}
		</cfscript>
		
		<cfif variables.titleYPos>
			<cfset titleSize = attributes.gridLabelFontSize + 10>
			<text style="fill:#attributes.gridLabelColour#;font-family:#attributes.gridLabelFont#;font-size:#variables.titleSize#;" y="#variables.titleYPos#" x="#variables.titleXPos#">#attributes.title#</text>
		</cfif>
		
		<!---:: end title ::--->
		
		<!---:: grid ::--->
		<cfif attributes.showGrid>
			<cfscript>
				vertLine1 = attributes.x + attributes.borderWidth + attributes.unitLength;
				numVertLines = (attributes.width / attributes.unitLength) - 2;
				vertTop = attributes.y;
				vertBottom = attributes.y + attributes.height;
				horLine1 = attributes.y + attributes.unitLength;
				horLineLast = attributes.y + attributes.height;
				horRight = attributes.x + attributes.width;
				pass = 0;
				gridLabelYPos = attributes.y - 10;
				attributes.width = attributes.width + (attributes.x - attributes.labelX);
			</cfscript>

			<!-- vertical bars -->
			<cfif attributes.showGridLabels>
					<cfscript>
						switch (attributes.gridUnits){
							case "month":
								thisMonth = dateAdd("m", 0, attributes.from);
								gridLabel = dateFormat(thisMonth,"mmm yy");
								gridLabelXPos = attributes.x - 15;
							break;
							case "day":
								thisDay = dateAdd("d", 0,attributes.from);
								gridLabel = dateFormat(thisDay,"mmm d");
								gridLabelXPos = attributes.x - 15;
							break;
						}
					</cfscript>
					<text style="fill:#attributes.gridLabelColour#;font-family:#attributes.gridLabelFont#;font-size:#attributes.gridLabelFontSize#;" y="#variables.gridLabelYPos#" x="#variables.gridLabelXPos#">#variables.gridLabel#</text>
			</cfif>
			
			<cfloop from="#variables.vertLine1#" to="#attributes.width#" step="#attributes.gridUnitLength#" index="i">
				<line x1="#i#" y1="#variables.vertTop#" x2="#variables.i#" y2="#variables.vertBottom#" style="stroke:#attributes.gridColour#;stroke-width:#attributes.gridWidth#;stroke-opacity:#attributes.gridOpacity#"/>
				<cfif attributes.showGridLabels>
					<cfscript>
						pass = variables.pass + 1;
						
						switch (attributes.gridUnits){
							case "month":
								thisMonth = DateAdd("m", variables.pass, attributes.from);
								gridLabel = dateFormat(thisMonth,"mmm");
								gridLabelXPos = variables.i - 10;
							break;
							case "day":
								if (not variables.pass mod 5){
									thisDay = DateAdd("d", variables.pass, attributes.from);
									gridLabel = dateFormat(thisDay,"d");
									gridLabelXPos = variables.i - 10;
								}
							break;
						}
					</cfscript>
					<text style="fill:#attributes.gridLabelColour#;font-family:#attributes.gridLabelFont#;font-size:#attributes.gridLabelFontSize#;" y="#variables.gridLabelYPos#" x="#variables.gridLabelXPos#">#variables.gridLabel#</text>
				</cfif>
			</cfloop>
			
			<cfif attributes.showGridLabels>
					<cfscript>
						switch (attributes.gridUnits){
							case "month":
								thisMonth = DateAdd("m", 0, attributes.to);
								gridLabel = dateFormat(thisMonth,"mmm yy");
								gridLabelXPos = attributes.x + attributes.width - 15 - (attributes.x - attributes.labelX);
							break;
							case "day":
								thisDay = DateAdd("d", 0, attributes.to);
								gridLabel = dateFormat(thisDay,"mmm d");
								gridLabelXPos = attributes.x + attributes.width - 5 - (attributes.x - attributes.labelX);
							break;
						}
					</cfscript>
					<text style="fill:#attributes.gridLabelColour#;font-family:#attributes.gridLabelFont#;font-size:#attributes.gridLabelFontSize#;" y="#variables.gridLabelYPos#" x="#variables.gridLabelXPos#">#variables.gridLabel#</text>
			</cfif>
			
			<!---:: bounding box ::--->
			<cfif attributes.showGridLabels and attributes.showLabelBox>
				<cfscript>
					labelBoxX = attributes.labelX - attributes.borderWidth;
					labelBoxWidth = attributes.x - variables.labelBoxX;
				</cfscript>
				<rect x="#variables.labelBoxX#" y="#attributes.y#" rx="#attributes.rx#" ry="#attributes.ry#" width="#variables.labelBoxWidth#" height="#attributes.height#"
				style="fill:#attributes.backgroundColour#;stroke:#attributes.borderColour#;stroke-width:#attributes.borderWidth#;fill-opacity:#attributes.backgroundOpacity#;stroke-opacity:#attributes.borderOpacity#"/>
			
			</cfif>
			
			<!---:: horizontal bars ::--->
			<cfloop from="#variables.horLine1#" to="#horLineLast#" step="#attributes.unitLength#" index="i">
				<line x1="#attributes.x#" y1="#variables.i#" x2="#variables.horRight#" y2="#variables.i#" style="stroke:#attributes.gridColour#;stroke-width:#attributes.gridWidth#;stroke-opacity:#attributes.gridOpacity#"/>
			</cfloop>
			
		</cfif>
		<!---:: end grid ::--->
		
		</cfoutput>
		<!---:: end define output ::--->
		
	</cfcase>
 
	<!---:: End mode ::--->
 	<cfcase value="End">		
		<!---:: define output here ::--->
		</svg>
		<!---:: end define output ::--->
	</cfcase>
	
 </cfswitch>


