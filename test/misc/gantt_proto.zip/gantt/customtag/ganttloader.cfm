<cfsilent>
<!---:: 
Application: CFI Gantt Chart
File: ganttLoader.cfm
Author: Simon Horwith
Purpose: puts data into session temp var and calls viewer
Dependencies:
	CSV Plug-in for viewing
	ganttViewer.cfm, ganttchart.cfm, and ganttchartitem.cfm are in the same directory
History:
27-8-04 : prototype created


Attributes:
	Attribute			Required			Description
	stData				 yes					structure containing chart and chartitem data
	
Other Notes: this file had to be added to the API because the <object> and <embed> tags make a seperate request.
The only way to pass data into an API is via the session scope and this controller file is required in order to allow multiple charts on a page.

 ::--->
 
 <!---:: ensure that the tag does not have an end tag ::--->
 <cfif thisTag.hasEndTag>
 	<cfthrow type="Gantt" message="End tag not allowed" detail="The ganttloader custom tag does not accept an end tag">
 </cfif>
 <cfif not structKeyExists(attributes, "stData")>
	<cfthrow type="Gantt" message="Required attribute missing" detail="The ganttloader custom tag requires an 'stData' attribute">
 </cfif>

 <!---:: validation and calculations ::--->
 <cfscript>
 	// all validation indexes
 	reqdDate = "from,to";
 </cfscript>
 <!---:: make sure stChart and aChildren exist and are valid data objects ::--->
 <cfif not isStruct(attributes.stData) or not structKeyExists(attributes.stData,"stChart") or  not structKeyExists(attributes.stData,"aChildren") or not isStruct(attributes.stData.stChart) or not isArray(attributes.stData.aChildren)>
 	<cfthrow type="Gantt" message="Invalid attribute Data" detail="The stData attribute must be a structure containing a 'stChart' struct and an 'aChildren' array">
 </cfif>
 
 <!---:: chart date validation ::--->
 <cfloop list="#variables.reqdDate#" index="i">
 	<cfif not structKeyExists(attributes.stData.stChart, variables.i) or not lsIsDate(attributes.stData.stChart[variables.i])>
		<cfthrow type="Gantt" message="Required attribute data missing" detail="The ganttchart custom tag requires a '#variables.i#' attribute with a valid date value">
	</cfif>
 </cfloop>
 <!---:: chart defaults ::--->
<cfparam name="attributes.stData.stChart.gridUnits" default="month">
<cfparam name="attributes.stData.stChart.itemUnits" default="day">
<cfparam name="attributes.stData.stChart.width" default="500">
<cfparam name="attributes.stData.stChart.height" default="0">
<cfparam name="attributes.stData.stChart.spacing" default="10">
<cfparam name="attributes.stData.stChart.itemHeight" default="10">
<cfparam name="attributes.stData.stChart.borderWidth" default="5">
<cfparam name="attributes.stData.stChart.borderColour" default="black">
<cfparam name="attributes.stData.stChart.borderOpacity" default="1">
<cfparam name="attributes.stData.stChart.backgroundColour" default="none">
<cfparam name="attributes.stData.stChart.backgroundOpacity" default="none">
<cfparam name="attributes.stData.stChart.x" default="20">
<cfparam name="attributes.stData.stChart.y" default="20">		
<cfparam name="attributes.stData.stChart.rx" default="0"> <!---:: for rounded corners, was 20 ::--->
<cfparam name="attributes.stData.stChart.ry" default="0"> <!---:: for rounded corners, was 20 ::--->		
<cfparam name="attributes.stData.stChart.showgrid" default="true"> 
<cfparam name="attributes.stData.stChart.showGridLabels" default="false">
<cfparam name="attributes.stData.stChart.spreadChildren" default="true">
<cfparam name="attributes.stData.stChart.gridColour" default="black">
<cfparam name="attributes.stData.stChart.gridWidth" default="1">
<cfparam name="attributes.stData.stChart.gridOpacity" default="0.25">
<cfparam name="attributes.stData.stChart.gridLabelColour" default="black">
<cfparam name="attributes.stData.stChart.gridLabelFont" default="Verdana">
<cfparam name="attributes.stData.stChart.showItemLabels" default="false">
<cfparam name="attributes.stData.stChart.labelX" default="20">
<cfparam name="attributes.stData.stChart.showLabelBox" default="true">
<cfparam name="attributes.stData.stChart.gridUnitLength" default="0">
<cfparam name="attributes.stData.stChart.gridLabelFontSize" default="10">
<cfparam name="attributes.stData.stChart.title" default="">
 <!---:: end chart defaults ::--->
 
 <cfscript>
	attributes.stData.stChart.itemUnits = trim(lCase(attributes.stData.stChart.itemUnits));
	attributes.stData.stChart.gridUnits = trim(lCase(attributes.stData.stChart.gridUnits));

	numericAttributes = "width,height,spacing,itemHeight,borderWidth,borderOpacity,x,y,rx,ry,gridWidth,gridOpacity,labelX,gridUnitLength,gridLabelFontSize";
	allowedUnits = "day,week,month,quarter,year,decade,century";
	booleanAttributes = "showgrid,showGridLabels,spreadChildren,showItemLabels,showLabelBox";
	//allowedFonts = "Arial,Helvetica,Verdana,ExPonto-Regular,Serpentine-Light,Utopia-Regular,Viva-Regular";
</cfscript>

<cfloop list="#variables.numericAttributes#" index="i">
	<cfif not isNumeric(attributes.stData.stChart[variables.i])>
		<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchart custom tag '#variables.i#' attribute must be a positive number">
	</cfif>
</cfloop>
<!---:: make sure font is OK ::--->
<!---:: <cfif not listFind(variables.allowedFonts, attributes.stData.stChart.gridLabelFont)>
	<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchart custom tag 'gridLabelFont' attribute must be one of the following: #variables.allowedFonts#">
</cfif> ::--->

<!---:: make sure measurement units are valid ::--->
<cfif not listFind(variables.allowedUnits, attributes.stData.stChart.gridUnits)>
	<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchart custom tag 'gridUnits' attribute must be one of the following: #variables.allowedUnits#">
<cfelseif not listFind(variables.allowedUnits, attributes.stData.stChart.itemUnits)>
	<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchart custom tag 'itemUnits' attribute must be one of the following: #variables.allowedUnits#">
</cfif>

<!---:: make sure certain attribs are Boolean ::--->
<cfloop list="#variables.booleanAttributes#" index="i">
	<cfif not isBoolean(attributes.stData.stChart[variables.i])>
		<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchart custom tag '#variables.i#' attribute must be a Boolean value">
	</cfif>
</cfloop>

<!---:: translate dates ::--->
<cfscript>
	// get item units into mask format
	switch(attributes.stData.stChart.itemUnits){
		case "day":
			itemUnitMask = "d";
		break;
		case "week":
			itemUnitMask = "ww";
		break;
		case "month":
			itemUnitMask = "m";
		break;
		case "quarter":
			itemUnitMask = "q";
		break;
		case "year": case "decade": case "century":
			itemUnitMask = "yyyy";
		break;
	}
	
	stDates = structNew();
	stDates.from = lsParseDateTime(attributes.stData.stChart.from);
	stDates.to = lsParseDateTime(attributes.stData.stChart.to);
	stDates.diff = dateDiff(variables.itemUnitMask,variables.stDates.from,variables.stDates.to);
	
	if (attributes.stData.stChart.showGrid){
		// get grid units into mask format
		switch(attributes.stData.stChart.gridUnits){
			case "day":
				gridUnitMask = "d";
			break;
			case "week":
				gridUnitMask = "ww";
			break;
			case "month":
				gridUnitMask = "m";
			break;
			case "quarter":
				gridUnitMask = "q";
			break;
			case "year": case "decade": case "century":
				gridUnitMask = "yyyy";
			break;
		}
		
		gridDatesDiff = dateDiff(variables.gridUnitMask,variables.stDates.from,variables.stDates.to);
	}
	
</cfscript>

<cfif variables.stDates.diff lt 1>
	<cfthrow type="Gantt" message="Invalid attribute values" detail="The ganttchart custom tag 'from' attribute must be prior to it's 'to' attribute">
</cfif>

<cfscript>
	// get rid of boundry box if not showing labels
	if (not attributes.stData.stChart.showItemLabels){
		attributes.stData.stChart.showLabelBox = false;
	}
	// set y if too small for gridlabels
	if (attributes.stData.stChart.showGridLabels and attributes.stData.stChart.y lt 11){
		attributes.stData.stChart.y = 11;
	}
	// set y if gridTitle passed
	if (attributes.stData.stChart.title is not ""){
		if (attributes.stData.stChart.showGridLabels and attributes.stData.stChart.y lt 51){
			attributes.stData.stChart.y = 51;
		} else if (not attributes.stData.stChart.showGridLabels and attributes.stData.stChart.y lt 41){
			attributes.stData.stChart.y = 41;
		}
	}
	
	
	// set x if too small for item labels
	if (attributes.stData.stChart.showItemLabels){
		biggestWord = 0;
		for (i = 1;i lte arrayLen(attributes.stData.aChildren); i = i + 1){
			if (isStruct(attributes.stData.aChildren[variables.i]) and structKeyExists(attributes.stData.aChildren[variables.i], "label")){
				if (len(attributes.stData.aChildren[variables.i].label) gt variables.biggestWord){
					variables.biggestWord = len(attributes.stData.aChildren[variables.i].label);
				}
			} else if (isArray(attributes.stData.aChildren[variables.i])){
				if (isStruct(attributes.stData.aChildren[variables.i][1]) and structKeyExists(attributes.stData.aChildren[variables.i][1], "label")){
					if (len(attributes.stData.aChildren[variables.i][1].label) gt variables.biggestWord){
						variables.biggestWord = len(attributes.stData.aChildren[variables.i][1].label);
					}
				}	
			}
		}
		if (attributes.stData.stChart.x lt variables.biggestWord * 8){
			attributes.stData.stChart.x = (variables.biggestWord * 8) + (attributes.stData.stChart.borderWidth * 2);
		}
		attributes.stData.stChart.labelX = attributes.stData.stChart.x - (variables.biggestWord * 8);
	} else {
		attributes.stData.stChart.labelX = 0;
	}

	attributes.stData.stChart.itemUnitLength = (attributes.stData.stChart.width - (attributes.stData.stChart.borderWidth * 2)) / variables.stDates.diff;
	if (attributes.stData.stChart.showGrid){
		// make daily grids use 5 day increments here?
		attributes.stData.stChart.gridUnitLength = (attributes.stData.stChart.width - (attributes.stData.stChart.borderWidth * 2)) / variables.gridDatesDiff;
	} else {
		attributes.stData.stChart.gridUnitLength = 0;
	}
	numChildren = arrayLen(attributes.stData.aChildren);
</cfscript>
<!---:: chart requires at least one item ::--->
<cfif not variables.numChildren>
	<cfthrow type="Gantt" message="Chart items required" detail="The gantt chart requires at least one child">
</cfif>
<!---:: if height was passed ::--->
<cfif attributes.stData.stChart.height>
	<cfscript>
		usedSpace = variables.numChildren * attributes.stData.stChart.itemHeight;
		freeSpace = attributes.stData.stChart.height - variables.usedSpace;
		
		if (variables.freeSpace gte variables.numChildren){
		// either space children apart or resize height
			if (attributes.stData.stChart.spreadChildren){
				attributes.stData.stChart.spacing = variables.freeSpace / variables.numChildren;
				numSpaces = variables.numChildren + 1;
			} else {
				// resize chart height (or not) here for free space!
				attributes.stData.stChart.spacing = attributes.stData.stChart.spacing + attributes.stData.stChart.itemHeight;
				numSpaces =  variables.numChildren + 1;
			}
			contentHeight = (attributes.stData.stChart.spacing * variables.numSpaces)  + variables.usedSpace;
		}
	</cfscript>
	
	<cfif variables.freeSpace lt variables.numChildren>
		<cfthrow type="Gantt" message="Chart too short" detail="The ganttchart custom tag 'height' attribute value cannot accomodate #variables.numChildren# items">
	</cfif>
	
	<!---:: code to handle if height is too small ::--->
	<cfif variables.contentHeight gt attributes.stData.stChart.height>
		<cfscript>
			if (variables.numSpaces){
				attributes.stData.stChart.spacing = variables.freeSpace / numSpaces;
			} else {
				attributes.stData.stChart.spacing = 1;
			}
		</cfscript>
	</cfif>
</cfif>
<!---:: end if height was passed ::--->
 
 <!---:: end chart validation ::--->
 
 <!---:: chart item validation ::--->
 <cffunction name="prepareChild" access="public" output="false" returntype="any">
 	<cfargument name="child" type="any" required="true">
	<cfargument name="unitMask" type="string" required="true">
	<cfargument name="unitLength" type="numeric" required="true">
	<cfargument name="from" type="date" required="true">
	<cfargument name="x" type="numeric" required="true">
	<cfargument name="width" type="numeric" required="true">
	<cfargument name="labelX" type="numeric" required="true">
	<cfargument name="showLabel" type="boolean" required="true">
		
	<cfscript>
		var z = "";
		var i = "";
		var retVal = "";
		var isOK = isStruct(arguments.child);
		var reqdDate = "from,to";
		var numericAttributes = "height,borderWidth,borderOpacity,x,y,rx,ry";
		var stDates = structNew();
		
		if (isArray(arguments.child)){
			retVal = arrayNew(1);
			for (z = 1; z lte arrayLen(arguments.child); z = z + 1){
				retVal[z] = prepareChild(arguments.child[z], arguments.unitMask,arguments.unitLength,arguments.from,arguments.x,arguments.width,arguments.labelX,arguments.showLabel);
			}
		}
	</cfscript>
	<!---:: process what was passed ::--->
	<cfif isOK>
		 <!---:: chart date validation ::--->
		<cfloop list="#reqdDate#" index="i">
			<cfif not structKeyExists(arguments.child, i) or not lsIsDate(arguments.child[i])>
				<cfthrow type="Gantt" message="Required attribute data missing" detail="The ganttchartitem custom tag requires a '#i#' attribute with a valid date value">
			</cfif>
		</cfloop>
		<!---:: default attribute values ::--->
		<cfparam name="arguments.child.height" default="10">
		<cfparam name="arguments.child.borderWidth" default="0">
		<cfparam name="arguments.child.borderColour" default="red">
		<cfparam name="arguments.child.borderOpacity" default="0">
		<cfparam name="arguments.child.backgroundColour" default="red">
		<cfparam name="arguments.child.backgroundOpacity" default="1">
		<cfparam name="arguments.child.x" default="25">
		<cfparam name="arguments.child.y" default="30">		
		<cfparam name="arguments.child.rx" default="0">
		<cfparam name="arguments.child.ry" default="0">
		<cfparam name="arguments.child.label" default="">
		<cfparam name="arguments.child.labelX" default="#arguments.labelX#">
		<cfparam name="arguments.child.shape" default="rect">
		<cfparam name="arguments.child.labelFont" default="Verdana">
		<cfparam name="arguments.child.labelFontSize" default="12">
		
		<!---:: validate attributes ::--->
		<cfloop list="#numericAttributes#" index="i">
			<cfif not isNumeric(arguments.child[i])>
				<cfthrow type="Gantt" message="Invalid attribute value" detail="The ganttchartitem custom tag '#i#' attribute must be a positive number">
			</cfif>
		</cfloop>		
		<!---:: end validate attributes ::--->
	
		<cfscript>
			stDates.from = lsParseDateTime(arguments.child.from);
			stDates.to = lsParseDateTime(arguments.child.to);
			stDates.diff = dateDiff(arguments.unitMask,stDates.from,stDates.to);
	 	</cfscript>
	
		<cfif variables.stDates.diff lt 1>
			<cfthrow type="Gantt" message="Invalid attribute values" detail="The ganttchartitem custom tag 'from' attribute must be prior to it's 'to' attribute">
		</cfif>
	
		<cfscript>
			stThisItem = structNew();
			stThisItem.units = stDates.diff;
			stThisItem.length = stThisItem.units * arguments.unitLength;
			stThisItem.startUnitOffset = dateDiff(arguments.unitMask,arguments.from,stDates.from);
			stThisItem.startPos = arguments.x + (stThisItem.startUnitOffset * arguments.unitLength);
			stThisItem.endPos = stThisItem.startPos +  stThisItem.length;

			arguments.child.x = stThisItem.startPos;
			//arguments.child.y = arguments.child.y - attributes.stData.stChart.spacing/2;
			// 'fix' label
			if (not arguments.showLabel){
				arguments.child.label = "";
			}
		</cfscript>
			
		<!---:: how to handle items begining before the chart from date ::--->
		<cfif stThisItem.startPos lt 0>
			<!---:: 
			<cfscript>
				// the following recalculates it's length and has it start from 0
				stThisItem.length = stThisItem.length + (stThisItem.startUnitOffset * arguments.unitLength);
				stThisItem.startPos = 0;
			</cfscript> 
			::--->
			<!---:: throw error ::--->
			<cfthrow type="Gantt" message="Invalid attribute values" detail="The ganttchartitem custom tag 'from' attribute must be after the chart 'to' attribute">
		</cfif>
		
		<!---:: how to handle items finishing after the chart to date ::--->
		<cfif stThisItem.endPos gt arguments.width + arguments.x>
			
			<!---:: 
			<cfscript>
				// the following recalculates it's length and has it end at the edge of the chart
				stThisItem.length = stThisItem.length - (stThisItem.endPos - arguments.width);
				stThisItem.endPos = arguments.width;
			</cfscript>
			 ::--->
			<cfthrow type="Gantt" message="Invalid attribute values" detail="The ganttchartitem custom tag 'to' attribute must be prior to the chart 'to' attribute">
		</cfif>
		<cfscript>
			arguments.child.width = stThisItem.length;
			retVal = duplicate(arguments.child);
		</cfscript>
	</cfif>
	<!---:: end process what was passed ::--->	
	
	<cfreturn retVal>
 </cffunction>

 <cfscript>
 	for (i = 1; i lte arrayLen(attributes.stData.aChildren); i = i + 1){
		attributes.stData.aChildren[variables.i] = prepareChild(attributes.stData.aChildren[variables.i], variables.itemUnitMask, attributes.stData.stChart.itemUnitLength,variables.stDates.from,attributes.stData.stChart.x +  attributes.stData.stChart.borderWidth,attributes.stData.stChart.width,attributes.stData.stChart.labelX,attributes.stData.stChart.showItemLabels);
	}
 </cfscript>
 
 <!---:: end chart item validation ::--->
 
<!---:: <cfdump var="#attributes#"><cfabort> ::--->
 
 <!---:: calculate new values for chart items ::--->
 
 	<!---:: manipulate nested tag output ::--->
	
	<cfscript>
		function fixChildAttribs(childData,spacing,itemHeight, pos){
			var retVal = "";
			var isOK = isStruct(childData);
			var i = "";
			if (isArray(arguments.childData)){
				retVal = arrayNew(1);
				for (i = 1; i lte arrayLen(arguments.childData); i = i + 1){
					retVal[i] = fixChildAttribs(arguments.childData[i],arguments.spacing,arguments.itemHeight,arguments.pos);
				}
			}
			if (isOK){
				retVal = duplicate(arguments.childData);
				retVal.y = arguments.childData.y + (arguments.pos * arguments.spacing) - arguments.childData.height;
				retVal.height = arguments.itemHeight;
			}
			return retVal;
		}

		for (i = 1; i lte variables.numChildren; i = i + 1){			
			attributes.stData.aChildren[variables.i] = fixChildAttribs(attributes.stData.aChildren[variables.i],attributes.stData.stChart.spacing,attributes.stData.stChart.itemHeight,variables.i);
		}
	</cfscript>

</cfsilent>
<!---:: <cfoutput>
 spacing: #attributes.stData.stChart.spacing#<br>
 numSpaces: #numSpaces#<br>
 freespace: #freespace#<br>
 usedSpace: #usedSpace#<br>
 height: #attributes.stData.stChart.height#
 </cfoutput><cfabort> ::--->
<!---:: <cfdump var="#attributes#"><cfabort> ::--->

<cflock name="ganttchart" type="EXCLUSIVE" timeout="20" throwontimeout="Yes">
<cfset session.stChartData = duplicate(attributes.stData)>
 <!---:: <cfinclude template="../ganttViewer.cfm"><cfabort> ::--->
 <object data="ganttViewer.cfm" width="100%"
height="100%" type="image/svg+xml">
<embed src="ganttViewer.cfm" width="100%"
height="100%" type="image/svg+xml" />
</object> 
<!---:: remove prior comment and enable this to use detection - the ''plugin' directory and contents must exist below application_store
<cfoutput>
<script language="JavaScript"><!--
emitSVG('src="ganttViewer.cfm" name="SVGEmbed" height="200" width="600" type="image/svg-xml"');
// -->
</script>
<noscript>
<embed src="ganttViewer.cfm" name="SVGEmbed" height="#attributes.stData.stChart.height#" width="#attributes.stData.stChart.width#" type="image/svg-xml"
pluginspage="#session.pluginPage#">
</noscript>
</cfoutput> ::--->

</cflock>