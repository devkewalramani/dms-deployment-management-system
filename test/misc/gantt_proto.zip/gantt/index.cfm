<h3>Gantt Chart API Samples</h3>
<a href="bars.cfm">Show larger blocks of time as bars</a><br>
<a href="triangles.cfm">Show individual points of time as triangles</a><br>
<a href="circles.cfm">Show individual points of time as circles</a><br>
