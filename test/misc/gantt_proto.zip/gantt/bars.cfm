<cfsilent>
<cfimport taglib="customtag" prefix="gant">

<cfscript>
	if (structKeyExists(url, "corners") and isNumeric(url.corners)){
		corners = url.corners;
	} else {
		corners = 0;
	}

	// generate some test data
	request.CSVData = structNew();
	
	request.CSVData.stChart = structNew();
	request.CSVData.stChart.from = lsDateFormat(dateAdd("yyyy", -1, now()));
	request.CSVData.stChart.to = lsDateFormat(now());
	request.CSVData.stChart.width = 500;
	request.CSVData.stChart.height = 200;
	request.CSVData.stChart.itemHeight = 10;
	request.CSVData.stChart.backgroundColour = "yellow";
	request.CSVData.stChart.backGroundOpacity = 0.2;
	request.CSVData.stChart.y = 20;
	request.CSVData.stChart.rx = variables.corners;
	request.CSVData.stChart.ry = variables.corners;
	request.CSVData.stChart.title = "Bars";
	request.CSVData.stChart.spreadChildren = true;
	request.CSVData.stChart.itemUnits = "day";
	request.CSVData.stChart.gridUnits = "month";
	request.CSVData.stChart.showGrid = true;	
	request.CSVData.stChart.showGridLabels = true;
	request.CSVData.stChart.showItemLabels = true;
	request.CSVData.stChart.showLabelBox = true;
	request.CSVData.aChildren = arrayNew(1);
	request.CSVData.aChildren[1] = arrayNew(1);
	request.CSVData.aChildren[1][1] = structNew();
	request.CSVData.aChildren[1][1].backgroundColour = "red";
//	request.CSVData.aChildren[1][1].from = lsDateFormat(dateAdd("d", -58, now()));
//	request.CSVData.aChildren[1][1].to = lsDateFormat(dateAdd("d", -21, now()));
	request.CSVData.aChildren[1][1].from = lsDateFormat(dateAdd("yyyy", -1, now()));
	request.CSVData.aChildren[1][1].to = lsDateFormat(dateAdd("m", -9, now()));
	request.CSVData.aChildren[1][1].label = "Simon Horwith";
	//request.CSVData.aChildren[1][1].shape = "circle";
	request.CSVData.aChildren[1][1].rx = variables.corners / 2;
	request.CSVData.aChildren[1][1].ry = variables.corners / 2;
	
	request.CSVData.aChildren[1][2] = structNew();
	request.CSVData.aChildren[1][2].backgroundColour = "red";
	request.CSVData.aChildren[1][2].from = lsDateFormat(dateAdd("m", -6, now()));
	request.CSVData.aChildren[1][2].to = lsDateFormat(dateAdd("m", -3, now()));
	request.CSVData.aChildren[1][2].label = "Jane";
	//request.CSVData.aChildren[1][2].shape = "circle";
	request.CSVData.aChildren[1][2].rx = variables.corners / 2;
	request.CSVData.aChildren[1][2].ry = variables.corners / 2;
	
	request.CSVData.aChildren[1][3] = structNew();
	request.CSVData.aChildren[1][3].backgroundColour = "red";
	request.CSVData.aChildren[1][3].from = lsDateFormat(dateAdd("m", -2, now()));
	request.CSVData.aChildren[1][3].to = lsDateFormat(dateAdd("m", -1, now()));
	request.CSVData.aChildren[1][3].label = "Simon";
	//request.CSVData.aChildren[1][3].shape = "circle";
	request.CSVData.aChildren[1][3].rx = variables.corners / 2;
	request.CSVData.aChildren[1][3].ry = variables.corners / 2;	
	
	request.CSVData.aChildren[2] = arrayNew(1);
	request.CSVData.aChildren[2][1] = structNew();
	request.CSVData.aChildren[2][1].backgroundColour = "blue";
	request.CSVData.aChildren[2][1].from = lsDateFormat(dateAdd("m", -3, now()));
	request.CSVData.aChildren[2][1].to = lsDateFormat(now());
	request.CSVData.aChildren[2][1].label = "Mark Biddles";
	//request.CSVData.aChildren[2][1].shape = "circle";
	request.CSVData.aChildren[2][1].rx = variables.corners / 2;
	request.CSVData.aChildren[2][1].ry = variables.corners / 2;
	
	request.CSVData.aChildren[2][2] = structNew();
	request.CSVData.aChildren[2][2].backgroundColour = "blue";
	request.CSVData.aChildren[2][2].from = lsDateFormat(dateAdd("m", -9, now()));
	request.CSVData.aChildren[2][2].to =lsDateFormat(dateAdd("m", -7, now()));
	request.CSVData.aChildren[2][2].label = "Bob";
	//request.CSVData.aChildren[2][2].shape = "circle";
	request.CSVData.aChildren[2][2].rx = variables.corners / 2;
	request.CSVData.aChildren[2][2].ry = variables.corners / 2;	
	
	request.CSVData.aChildren[3] = arrayNew(1);
	request.CSVData.aChildren[3][1] = structNew();
	request.CSVData.aChildren[3][1].backgroundColour = "green";
	request.CSVData.aChildren[3][1].from = lsDateFormat(dateAdd("d", -39, now()));
	request.CSVData.aChildren[3][1].to = lsDateFormat(now());
	request.CSVData.aChildren[3][1].label = "Ralf Sandys";
	//request.CSVData.aChildren[3][1].shape = "circle";
	request.CSVData.aChildren[3][1].rx = variables.corners / 2;
	request.CSVData.aChildren[3][1].ry = variables.corners / 2;	
	
	request.CSVData.aChildren[3][2] = structNew();
	request.CSVData.aChildren[3][2].backgroundColour = "green";
	request.CSVData.aChildren[3][2].from = lsDateFormat(dateAdd("d", -209, now()));
	request.CSVData.aChildren[3][2].to =lsDateFormat(dateAdd("d", -107, now()));
	request.CSVData.aChildren[3][2].label = "Ralf";
	//request.CSVData.aChildren[3][2].shape = "circle";
	request.CSVData.aChildren[3][2].rx = variables.corners / 2;
	request.CSVData.aChildren[3][2].ry = variables.corners / 2;	
	
	/*request.CSVData.aChildren[4] = structNew();
	request.CSVData.aChildren[4].backgroundColour = "purple";
	request.CSVData.aChildren[4].from = lsDateFormat(dateAdd("m", -9, now()));
	request.CSVData.aChildren[4].to = lsDateFormat(dateAdd("m", -2, now()));
	request.CSVData.aChildren[4].label = "Duncan";*/
</cfscript>
</cfsilent>

<h3>Bars Example</h3>
<cfoutput>
<cfif variables.corners>
<a href="#cgi.script_name#">Show with square corners</a><br>
<cfelse>
<a href="#cgi.script_name#?corners=20">Show with round corners</a><br>
</cfif>
</cfoutput>
<!---:: render SVG ::--->
<gant:ganttloader stData="#request.CSVData#">