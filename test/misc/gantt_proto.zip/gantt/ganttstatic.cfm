<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Generating a Static SVG Gantt Chart</title>
</head>

<body>

<object data="static.cfm" width="100%"
height="100%" type="image/svg+xml">
<embed src="static.cfm" width="100%"
height="100%" type="image/svg+xml" />
</object>

</body>
</html>