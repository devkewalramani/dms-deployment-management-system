
<cfscript>
	thisOutput = '<rect x="25" y="30" rx="10" ry="10" width="200" height="10" style="fill:red;stroke:red;stroke-width:0;fill-opacity:1.0;stroke-opacity:1.0"/>';
	/*
	replaceString = 'height="99"';
	regEx = 'height[\s]*[=]{1}[\s]*[#chr(39)##chr(34)#]{1}[0-9]{1,}[#chr(39)##chr(34)#]{1}';
	thisOutput = reReplaceNoCase(thisOutput, regEx, replaceString);
	*/
	// thisTag.assocAttribs[variables.i].content
	//yStart = reFindNoCase("y[\s]*[=]{1}",thisOutput);
	yRegEx = 'y[\s]*[=]{1}[\s]*[#chr(39)##chr(34)#]{1}[0-9]{1,}[#chr(39)##chr(34)#]{1}';
	yTmp = reFindNoCase(yRegEx, thisOutput, 1, true);
	yExp = mid(thisOutput,yTmp.pos[1], yTmp.len[1]);
	yNumber = reReplaceNoCase(yExp,"[^0-9]","","ALL");
	thisnewOutput = left(thisOutput, yTmp.pos[1] - 1) & 'y="555"' & right(thisOutput, len(thisOutput) - (yTmp.pos[1] + yTmp.len[1] - 1));
	
	//yReplaceRegEx = '(.)*y[\s]*[=]{1}[\s]*[#chr(39)##chr(34)#]{1}[0-9]{1,}[#chr(39)##chr(34)#]{1}';
	//	yEnd = reFindNoCase("(#yRegEx#)", thisOutput, yStart);
	//yTst = reFindNoCase(yReplaceRegEx, thisOutput,
	//yTst = reReplaceNoCase(thisOutput,yReplaceRegEx,"");
	//("(#yRegEx#)", thisOutput, yStart);
	//yTmpStr = right(thisOutput, len(thisOutput) - yStart);
	//yTmp = reReplaceNoCase(yTmpStr,"[^0-9]","","ALL");
	/*
	yPosReplaceString = 'y="'911"';
	yPosRegEx = 'y[\s]*[=]{1}[\s]*[#chr(39)##chr(34)#]{1}[0-9]{1,}[#chr(39)##chr(34)#]{1}';
	thisOutput = reReplaceNoCase(thisOutput, yPosRegEx, yPosReplaceString);
	*/
</cfscript> 

<cfdump var="#variables#">