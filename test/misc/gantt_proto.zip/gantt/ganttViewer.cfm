<cfsilent>
<cfimport taglib="customtag" prefix="gant">
</cfsilent>
	<gant:ganttchart 
	itemUnits="#session.stChartData.stChart.itemUnits#" 
	gridUnits="#session.stChartData.stChart.gridUnits#" 
	width="#session.stChartData.stChart.width#" 
	height="#session.stChartData.stChart.height#" 
	from="#session.stChartData.stChart.from#" 
	to="#session.stChartData.stChart.to#"
	itemHeight="#session.stChartData.stChart.itemHeight#"
	y="#session.stChartData.stChart.y#"
	backgroundColour = "#session.stChartData.stChart.backgroundColour#"
	backgroundOpacity = "#session.stChartData.stChart.backgroundOpacity#"
	borderColour = "#session.stChartData.stChart.borderColour#"
	borderOpacity = "#session.stChartData.stChart.borderOpacity#"
	borderWidth = "#session.stChartData.stChart.borderWidth#"
	rx = "#session.stChartData.stChart.rx#"
	ry = "#session.stChartData.stChart.ry#"
	showGrid = "#session.stChartData.stChart.showGrid#"
	spacing = "#session.stChartData.stChart.spacing#"
	spreadChildren = "#session.stChartData.stChart.spreadChildren#"
	x = "#session.stChartData.stChart.x#"
	unitLength = "#session.stChartData.stChart.gridUnitLength#"
	showGridLabels = "#session.stChartData.stChart.showGridLabels#"
	showItemLabels = "#session.stChartData.stChart.showItemLabels#"
	gridLabelFont = "#session.stChartData.stChart.gridLabelFont#"
	gridLabelColour = "#session.stChartData.stChart.gridLabelColour#"
	gridWidth = "#session.stChartData.stChart.gridWidth#"
	gridColour = "#session.stChartData.stChart.gridLabelFont#"
	gridOpacity = "#session.stChartData.stChart.gridOpacity#"
	labelX = "#session.stChartData.stChart.labelX#"
	showLabelBox = "#session.stChartData.stChart.showLabelBox#"
	gridUnitLength = "#session.stChartData.stChart.gridUnitLength#"
	gridLabelFontSize = "#session.stChartData.stChart.gridLabelFontSize#"
	title = "#session.stChartData.stChart.title#">
	
	
	<cfloop from="1" to="#arrayLen(session.stChartData.aChildren)#" index="i">
		<!---:: <cfset yPos = session.stChartData.stChart.y + (session.stChartData.stChart.itemHeight * variables.i)> ::--->
		<cfif isArray(session.stChartData.aChildren[variables.i])>
		
			<cfloop from="1" to="#arrayLen(session.stChartData.aChildren[variables.i])#" index="j">
			<cfif j gt 1>
				<cfset session.stChartData.aChildren[variables.i][variables.j].label = "">
			</cfif>
			<gant:ganttchartitem 
				width="#session.stChartData.aChildren[variables.i][variables.j].width#" 
				height="#session.stChartData.aChildren[variables.i][variables.j].height#" 
				from="#session.stChartData.aChildren[variables.i][variables.j].from#" 
				to="#session.stChartData.aChildren[variables.i][variables.j].to#"
				y="#session.stChartData.aChildren[variables.i][variables.j].y#"
				backgroundColour = "#session.stChartData.aChildren[variables.i][variables.j].backgroundColour#"
				backgroundOpacity = "#session.stChartData.aChildren[variables.i][variables.j].backgroundOpacity#"
				borderColour = "#session.stChartData.aChildren[variables.i][variables.j].borderColour#"
				borderOpacity = "#session.stChartData.aChildren[variables.i][variables.j].borderOpacity#"
				borderWidth = "#session.stChartData.aChildren[variables.i][variables.j].borderWidth#"
				rx = "#session.stChartData.aChildren[variables.i][variables.j].rx#"
				ry = "#session.stChartData.aChildren[variables.i][variables.j].ry#"
				x = "#session.stChartData.aChildren[variables.i][variables.j].x#"
				label = "#session.stChartData.aChildren[variables.i][variables.j].label#"
				labelX = "#session.stChartData.aChildren[variables.i][variables.j].labelX#"
				shape = "#session.stChartData.aChildren[variables.i][variables.j].shape#"
				labelFont = "#session.stChartData.aChildren[variables.i][variables.j].labelFont#"
				labelFontSize = "#session.stChartData.aChildren[variables.i][variables.j].labelFontSize#"
			>
			</cfloop>
		<cfelse>
			<gant:ganttchartitem 
				width="#session.stChartData.aChildren[variables.i].width#" 
				height="#session.stChartData.aChildren[variables.i].height#" 
				from="#session.stChartData.aChildren[variables.i].from#" 
				to="#session.stChartData.aChildren[variables.i].to#"
				y="#session.stChartData.aChildren[variables.i].y#"
				backgroundColour = "#session.stChartData.aChildren[variables.i].backgroundColour#"
				backgroundOpacity = "#session.stChartData.aChildren[variables.i].backgroundOpacity#"
				borderColour = "#session.stChartData.aChildren[variables.i].borderColour#"
				borderOpacity = "#session.stChartData.aChildren[variables.i].borderOpacity#"
				borderWidth = "#session.stChartData.aChildren[variables.i].borderWidth#"
				rx = "#session.stChartData.aChildren[variables.i].rx#"
				ry = "#session.stChartData.aChildren[variables.i].ry#"
				x = "#session.stChartData.aChildren[variables.i].x#"
				label = "#session.stChartData.aChildren[variables.i].label#"
				labelX = "#session.stChartData.aChildren[variables.i].labelX#"
				shape = "#session.stChartData.aChildren[variables.i].shape#"
				labelFont = "#session.stChartData.aChildren[variables.i].labelFont#"
				labelFontSize = "#session.stChartData.aChildren[variables.i].labelFontSize#"
			>
		</cfif>
	</cfloop>
</gant:ganttchart>