<svg width="300" height="300">
<!-- border -->
<rect x="20" y="20" rx="0" ry="0" width="500" height="200"
style="fill:none;stroke:black;stroke-width:5;fill-opacity:1.0;stroke-opacity:1.0"/>
<!-- grid -->
<cfoutput>
<!-- vertical bars -->
<cfloop from="30" to="510" index="i" step="10">
<!---:: <cfif not i mod 100>
<text style="fill:black,font-family:Helvetica" y="15" x="#i#">#i#</text>
</cfif> ::--->
<line x1="#i#" y1="25" x2="#i#" y2="220"
style="stroke:black;stroke-width:1;stroke-opacity:.25"/>
</cfloop>
<!-- horizontal bars -->
<cfloop from="30" to="210" index="i" step="10">
<line x1="20" y1="#i#" x2="520" y2="#i#"
style="stroke:black;stroke-width:1;stroke-opacity:.25"/>
</cfloop>
</cfoutput>
<!-- row 1 -->
<polygon points="20,30 30,30 25,20"
style="fill:red;stroke:red;stroke-width:0"/>
<!--
<rect x="25" y="30" rx="0" ry="0" width="200" height="10"
style="fill:red;stroke:red;stroke-width:0;fill-opacity:1.0;stroke-opacity:1.0"/>-->
<!--<rect x="275" y="30" rx="0" ry="0" width="100" height="10"
style="fill:red;stroke:red;stroke-width:0;fill-opacity:1.0;stroke-opacity:1.0"/>-->
<!-- row 2 -->
<!--<rect x="125" y="50" rx="0" ry="0" width="190" height="10"
style="fill:blue;stroke:blue;stroke-width:0;fill-opacity:1.0;stroke-opacity:1.0"/>-->
</svg>