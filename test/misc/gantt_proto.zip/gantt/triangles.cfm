<cfsilent>
<cfimport taglib="customtag" prefix="gant">
<cfscript>
	// generate some test data
	request.CSVData = structNew();
	
	request.CSVData.stChart = structNew();
	request.CSVData.stChart.from = lsDateFormat(dateAdd("m", -1, now()));
	request.CSVData.stChart.to = lsDateFormat(now());
	request.CSVData.stChart.width = 250;
	request.CSVData.stChart.height = 100;
	request.CSVData.stChart.itemHeight = 10;
	request.CSVData.stChart.backgroundColour = "yellow";
	request.CSVData.stChart.backGroundOpacity = 0.2;
	request.CSVData.stChart.y = 20;
	request.CSVData.stChart.spreadChildren = true;
	request.CSVData.stChart.itemUnits = "day";
	request.CSVData.stChart.gridOpacity = 1.0;
	request.CSVData.stChart.gridUnits = "day";
	request.CSVData.stChart.showGrid = true;	
	request.CSVData.stChart.showGridLabels = true;
	request.CSVData.stChart.showItemLabels = true;
	request.CSVData.stChart.showLabelBox = true;
	request.CSVData.aChildren = arrayNew(1);
	request.CSVData.aChildren[1] = arrayNew(1);
	request.CSVData.aChildren[1][1] = structNew();
	request.CSVData.aChildren[1][1].backgroundColour = "red";
//	request.CSVData.aChildren[1][1].from = lsDateFormat(dateAdd("d", -58, now()));
//	request.CSVData.aChildren[1][1].to = lsDateFormat(dateAdd("d", -21, now()));
	request.CSVData.aChildren[1][1].from = lsDateFormat(dateAdd("d", -25, now()));
	request.CSVData.aChildren[1][1].to = lsDateFormat(dateAdd("d", -24, now()));
	request.CSVData.aChildren[1][1].label = "Simon Horwith";
	request.CSVData.aChildren[1][1].shape = "triangle";
		
	request.CSVData.aChildren[1][2] = structNew();
	request.CSVData.aChildren[1][2].backgroundColour = "red";
	request.CSVData.aChildren[1][2].from = lsDateFormat(dateAdd("d", -18, now()));
	request.CSVData.aChildren[1][2].to = lsDateFormat(dateAdd("d", -17, now()));
	request.CSVData.aChildren[1][2].label = "Simon Horwith";
	request.CSVData.aChildren[1][2].shape = "triangle";
	request.CSVData.aChildren[1][3] = structNew();
	request.CSVData.aChildren[1][3].backgroundColour = "red";
	request.CSVData.aChildren[1][3].from = lsDateFormat(dateAdd("d", -10, now()));
	request.CSVData.aChildren[1][3].to = lsDateFormat(dateAdd("d", -11, now()));
	request.CSVData.aChildren[1][3].label = "Simon";
	request.CSVData.aChildren[1][3].shape = "triangle";
	request.CSVData.aChildren[2] = arrayNew(1);
	request.CSVData.aChildren[2][1] = structNew();
	request.CSVData.aChildren[2][1].backgroundColour = "blue";
	request.CSVData.aChildren[2][1].from = lsDateFormat(dateAdd("d", -7, now()));
	request.CSVData.aChildren[2][1].to = lsDateFormat(dateAdd("d", -6, now()));
	request.CSVData.aChildren[2][1].label = "Mark Biddles";
	request.CSVData.aChildren[2][1].shape = "triangle";
	request.CSVData.aChildren[2][2] = structNew();
	request.CSVData.aChildren[2][2].backgroundColour = "blue";
	request.CSVData.aChildren[2][2].from = lsDateFormat(dateAdd("d", -2, now()));
	request.CSVData.aChildren[2][2].to =lsDateFormat(dateAdd("d", -1, now()));
	request.CSVData.aChildren[2][2].label = "Mark Biddles";
	request.CSVData.aChildren[2][2].shape = "triangle";
	request.CSVData.aChildren[3] = arrayNew(1);
	request.CSVData.aChildren[3][1] = structNew();
	request.CSVData.aChildren[3][1].backgroundColour = "green";
	request.CSVData.aChildren[3][1].from = lsDateFormat(dateAdd("d", -29, now()));
	request.CSVData.aChildren[3][1].to = lsDateFormat(dateAdd("d", -28, now()));
	request.CSVData.aChildren[3][1].label = "Ralf Sandys";
	request.CSVData.aChildren[3][1].shape = "triangle";
	request.CSVData.aChildren[3][2] = structNew();
	request.CSVData.aChildren[3][2].backgroundColour = "green";
	request.CSVData.aChildren[3][2].from = lsDateFormat(dateAdd("d", -12, now()));
	request.CSVData.aChildren[3][2].to =lsDateFormat(dateAdd("d", -13, now()));
	request.CSVData.aChildren[3][2].label = "Ralf";
	request.CSVData.aChildren[3][2].shape = "triangle";
</cfscript>
</cfsilent>
<h3>Triangles Example</h3>
<!---:: render SVG ::--->
<gant:ganttloader stData="#request.CSVData#">