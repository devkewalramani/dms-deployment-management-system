<!---:: this had to be created so sessions are enabled  ::--->
<cfapplication name="gantt" sessionmanagement="Yes">

<!---:: uncomment to turn on detection
<cfscript>
	session.pluginPage = request.paths.root_path & request.paths.separator & "plugin/install.cfm";
	pluginJSFile = request.paths.home_url & "plugin/svgcheck.cfm";
	pluginVBSFile = request.paths.home_url & "plugin/svgcheckvbs.cfm";
</cfscript>

<cfinclude template="#variables.pluginVBSFile#">
<cfinclude template="#variables.pluginJSFile#">

<!---:: call method to detect plug-in ::--->
<script language="JavaScript"><!--
	checkAndGetSVGViewer();
	// -->
</script>
 ::--->
<!---:: on caller page ::--->

<!---:: this is for logging ::--->
<cfscript>
	request.doLogging = true;
	request.loggingDirectory = "C:\JRun4\servers\Development\cfusion_ear\cfusion_war\RD\gantt\gantt_log";
	request.appName = "gantt";
</cfscript>