<!-- (c) copyright 2004, Orville Paul Chomer, All Rights Reserved. -->

<html>
<head>
<title>Test Date Entry</title>
<style>
  body { font-family: tahoma; font-size: 11pt; background-color : #FFD700;} 
  td { font-size: 11pt; }
  
  .sample1 {
  	font-family: Geneva, Arial, Helvetica, sans-serif;
  	font-size: 11px;
  	color: #333333;
  	background-color: #E6F4D0;
  	border: 1px solid #333333;
  	padding: 2px;
  	height: 21px;
  }


  .sample2 {
  	font-family: Geneva, Arial, Helvetica, sans-serif;
  	font-size: 11px;
  	color: #333333;
  	background-color: #F1C9EF;
  	border: 1px solid #333333;
  	padding: 2px;
  	height: 21px;
  }
  
</style>
</head>
<body>

<form name="frm">
<h3>DATE_TEST.CFM</h3>
<HR>
<table>
<tr>
<td>Test Date 1:</td><td><cf_ct_date_input name="test_date" value="01/02/2004"></td>
<td>Test Date 2:</td><td><cf_ct_date_input name="test_date2" 
    value="11/03/2004" 
    class="sample1" 
    button_color="##D9EFA8"
    BUTTON_EDGE_COLOR="##999999" 
	SELBGCOLOR="##66CC33"
	BACK_COLOR="##E6F4D0"
	CALCOLOR="##E6F4D0"	></td>
<td>Test Date 3:</td><td><cf_ct_date_input name="test_date3" style="color: red;"
value="12/04/2004" ></td>
</tr>

<tr>
<td>Test Date 4:</td><td><cf_ct_date_input name="test_date4" value="03/08/2003" ></td>
<td>Test Date 5:</td><td><cf_ct_date_input 
            name="test_date5"
            class="sample2"
            button_color="##F1C9EF"
            hdcolor="##FFD2D2"
            BACK_COLOR="##FF6F6F"
            CALCOLOR="##FFD2D2"
            CALFONTCOLOR="red"
            BUTTON_EDGE_COLOR="##9D0000"
            CAL_BORDER_COLOR="##9D0000"
            SELBGCOLOR="##FF6F6F"
            value="11/09/2002" ></td>
<td>Test Date 6:</td><td><cf_ct_date_input name="test_date6" value="11/10/2000" ></td>
</tr>

<tr>
<td>Test Date 7:</td><td><cf_ct_date_input name="test_date7" value="06/05/2004" ></td>
<td>Test Date 8:</td><td><cf_ct_date_input name="test_date8" value="07/06/2004" ></td>
<td>Test Date 9:</td><td><cf_ct_date_input name="test_date9" value="10/07/2004" ></td>
</tr>

<tr>
<td>Test Date 10:</td><td><cf_ct_date_input name="test_date10" value="" ></td>
<td>Test Date 11:</td><td><cf_ct_date_input name="test_date11" value="09/15/2004" ></td>
<td>Test Date 12:</td><td><cf_ct_date_input name="test_date12" value="" ></td>
</tr>
</table>


<BR>Scroll Test - Scroll Test -&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<B>Try scrolling around and picking dates!</B>
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -

<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>
<table width="100%" ><tr>
<td nowrap width="300">Scroll Test - Scroll Test - <i>Disabled</i> date:</td><td width="*" nowrap><cf_ct_date_input name="dis_test_date" value="04/10/2004" disabled></td>
</tr></table>

<BR>Scroll Test - Scroll Test -
<table><tr>
<td>To the right is date control using ONCHANGE. Pick a date using it to see what happens!</td>
<td><cf_ct_date_input name="test_date_evnt" 
onchange="alert('You changed the date to: '+this.value)"
value="12/04/2004" ></td>
</tr></table>
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>
<TABLE><TR><TD NOWRAP>
Scroll Test - Scroll Test - Scroll Test - Scroll Test - Scroll Test - Scroll Test - Scroll Test - Scroll Test -  - Scroll Test - Scroll Test -  - Scroll Test - Scroll Test -  - Scroll Test - Scroll Test -  - Scroll Test - Scroll Test -  - Scroll Test - Scroll Test - 
</TD></TR></TABLE>
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -

<table>
<tr>
<td>Test Date 1:</td><td><cf_ct_date_input name="test_date13" value="01/02/2004" BACK_COLOR="##F0E68C"></td>
<td>Test Date 2:</td><td><cf_ct_date_input name="test_date14" value="11/03/2004" ></td>
<td>Test Date 3:</td><td><cf_ct_date_input name="test_date15" value="12/04/2004" ></td>
</tr>

<tr>
<td>Test Date 4:</td><td><cf_ct_date_input name="test_date16" value="03/08/2003" ></td>
<td>Test Date 5:</td><td><cf_ct_date_input name="test_date17" value="11/09/2002" ></td>
<td>Test Date 6:</td><td><cf_ct_date_input name="test_date18" value="11/10/2000" ></td>
</tr>

<tr>
<td>Test Date 7:</td><td><cf_ct_date_input name="test_date19" value="06/05/2004" ></td>
<td>Test Date 8:</td><td><cf_ct_date_input name="test_date20" value="07/06/2004" ></td>
<td>Test Date 9:</td><td><cf_ct_date_input name="test_date21" value="10/07/2004" ></td>
</tr>

<tr>
<td>Test Date 10:</td><td><cf_ct_date_input name="test_date22" value="" ></td>
<td>Test Date 11:</td><td><cf_ct_date_input name="test_date23" value="09/15/2004" ></td>
<td>Test Date 12:</td><td><cf_ct_date_input name="test_date24" value="" ></td>
</tr>
</table>
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<BR>Scroll Test - Scroll Test -
<DIV STYLE="overflow: scroll; width: 400px; height: 200px; border: solid black 1px; background-color: lightgreen;">
   <BR><BR><BR><BR>A date control inside a scrollable layer (DIV) tag:<BR><BR>
   <cf_ct_date_input name="test_date25" value="09/15/2005" >
   <BR><BR><BR>
   Another Date:<BR>
   <cf_ct_date_input name="test_date26" value="09/16/2005" >
   <BR>
   <TABLE><TR><TD WIDTH="40">&nbsp;</TD>
   <TD><DIV STYLE="overflow: scroll; width: 200px; height: 200px; border: solid black 1px; background-color: lightyellow;">
      <cf_ct_date_input name="test_date27" value="09/17/2005" >
   </DIV></TD>
   </TR></TABLE>
</DIV>

</form>
</body>
</html>