*******************************************
   COLDFUSION CUSTOM TAG - DATE CONTROL
*******************************************

(c) copyright 2004-2005, Orville Paul Chomer (Chomer.com)
All Rights Reserved.

*******************************************

You are free to use this custom tag at no charge.
You can distribute the custom tag as long as its not modified.
The copyright notice, all the comments, etc. must remain intact.

*******************************************

Hope you find this custom tag useful!

*******************************************

Best Regards,

Orville Chomer
(Chomer.com)


 @@@@@@@@@@@@@@@@@@@@@@@ CHANGES AND UPDATES @@@@@@@@@@@@@@@@@ 

     FOR V: 2.0:
     7/28/05 - Now if the date control is too low on the page
               (the popup gets cut off), the popup will be placed
               Above the control instead of Below the control. OC

     7/28/05 - Bug created by ver 1.4 has been fixed. If you clicked
               on the text area of the control before clicking on
               the popup button, you would get a Javascript error.
               This bug has been fixed. OC

     FOR V: 1.4:   
     5/26/05 - Finally fixed the positioning of the pop-up if its
               buried in a layer. In the previous version, if the
               first date control was Not in a layer then the ones
               in the layers would work.  Instead of putting the
               date control whereever the first control was placed,
               it now puts it right After the BODY tag. Although
               in the style I'm using position: absolute (which,
               in my opinion, should just work...) it doesn't!
               IE is fussy about layering sometimes. If you put 
               a layer <DIV> inside the <BODY> tag, but outside
               any tables or other layers, it works just as you'd
               expect. Hence the new code to deliberately places
               the layer at the top of the page after the <BODY>
               tag!  OC

     FOR V: 1.3:
     3/31/05 - Modified the code that calculates how many days are
               in each month. Some subsequent update of Internet
               Explorer "broke" the original code. I wrote new code
               that is not dependent on the Date object functioning
               the way it was assumed before.  OC

     FOR V: 1.2:
     9/30/04 - Added a Clear button to the calendar popup so a user
               can clear out the current date in the control. This
               is especially important if a user accidentally picks
               a date and then realizes the value should still be 
               blank!  OC
    
     FOR Version: 1.1:
     9/27/04 - Changed CALLER to REQUEST variable to eliminate 
               problems with using this custom tag inside another
               custom tag. OC
     9/27/04 - Added javascript to change z-order of popup so it 
               will show properly when tag embedded on 
               a lower layer. OC
     9/27/04 - Added READONLY attribute, works like READONLY on 
               normal INPUT tag.
     9/27/04 - Added LOCKED attribute, use for dynamically disabling control.
               --- CHECK MORE INFO ON DISABLING BELOW! ---

     9/27/04 - Add ONCHANGE attribute. Works like ONCHANGE attribute of a
               SELECT tag. Use javascript in this tag the same way.
               So, now you can run javascript to do something when user picks 
               a date!

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ISSUES
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   * As of right now, I believe this control only works ok with Internet 
     Explorer.

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ISSUES THAT HAVE BEEN ADDRESSED:
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
   * The Popup not appearing in the proper position in a scrollable layer
     has been fixed (v1.4). For IE, this makes this control at this point
     a really excellent date control to use. (Of course that's my opinion!)



@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

          INSTRUCTIONS

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
ABOUT:
 This custom tag which I wrote allows easy user input of a date.
 Just put this tag in your web page the same way you would place
 an <INPUT> tag, set the proper attributes, and, wal-la! A working
 date control!

TERMS OF USE:
 You may use this tag in any ColdFusion project you wish. Totally
 for free! The only thing I ask is that you leave the custom tag 
 file intact as it was (including all the comments at the top).

SUPPORT:
 This custom is provided as-is. Your are responsible to test and 
 make sure that it works properly on your web page, not me (I 
 think this is only fair especially since it's free)!

FEATURES:
 * Works like a standard INPUT tag
 * Needs no other external files (minus image of calendar).
 * Works with your style sheets' classes (has a CLASS attribute).
 * Has a STYLE attribute.
 * Allows customizing of colors for various parts of calendar popup.

HOW IT WORKS:
 * User can see the current date the control is currently set at.
 * User can click date pick button to the right to bring up calendar.
 * Popup calendar allows user to navigate to date they desire and click
  to select.

PAGE USAGE:
 Here how to use the tag...
 1.  Make sure that this custom tag is either in a custom tag directory on 
     the ColdFusion server or in the same directory as the page that will be
     using it.
 2.  Make sure that the calendar image is in the same directory as the page
     using it (there are exceptions).
 3.  On your page, instead of using an <INPUT TYPE="text"> tag, use this custom tag!

SYNTAX:
   <CF_CT_DATE_INPUT
        NAME="form_input_name"     (required)
        VALUE="12/10/2004"         (works just like INPUT tag's value Attribute)
        CLASS="a_css_class"        (optional. works as expected)
        STYLE="a css string"       (optional. works as expected)
        DISABLED                   (optional. if there, date pick button is disabled)
        READONLY                   (optional. works the same as DISABLED)
        LOCKED                     (optional. for dynamic disabling. a value of "READONLY" or "Y" disables control.
        BTN_SRC                    (optional. URL of image file to use other than one provided)
        HD_COLOR                   (optional)
        SELBGCOLOR                 (optional)
        SELFGCOLOR                 (optional)
        CALCOLOR                   (optional)
        CALFONTCOLOR               (optional)
        BUTTON_EDGE_COLOR          (optional)
        BUTTON_COLOR               (optional)
        BACK_COLOR                 (optional)
        CAL_BORDER_COLOR           (optional)
        
    >


MORE ON SOME ATTRIBUTES:
   HD_COLOR - Background color of calendar heading (for days of the week).
   SELBGCOLOR - Background color of a selected day.
   SELFGCOLOR - Foreground color of a selected day.
   CALCOLOR - Background color of a day on the calendar.
   CALFONTCOLOR - Color of date number on the calendar.
   BUTTON_EDGE_COLOR - Color of button edge for buttons on the calendar pop-up.
   BUTTON_COLOR - Color of popup button as well as buttons on the calendar pop-up.
   BACK_COLOR - Background color of popup.
   CAL_BORDER_COLOR - Color of the calendar's border around each day!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

USING THE VALUE

Let us look at a small sample page:

------------------------------------------------------
<HTML>
<HEAD>

</HEAD>
<BODY>
  <FORM NAME="frm" METHOD="post" action="checkit.cfm">
    <CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004">
    <INPUT TYPE="SUBMIT" VALUE="POST">
  </FORM>
</BODY>
</HTML>
-------------------------------------------------------

In checkit.cfm, we can get the value from:   FORM.sample_fld

In the original page, we could use javascript to do something like:

   alert(document.frm.sample_fld.value)

to display the value!

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

INFO ABOUT DISABLING CONTROL

Example #1:
<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" DISABLED>

This will work.


Example #2:
<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" READONLY>

This will work.

Example #3:

<cfset sReadOnly = " READONLY ">
<INPUT NAME="sample_fld" VALUE="11/04/2004" #sReadOnly#>

This example using a standard INPUT tag works as expected. but...

Example #4:

<cfset sReadOnly = " READONLY ">
<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" #sReadOnly#>

This example will NOT WORK!  It should in my opinion... but it does not!

To get around this I've added a LOCKED attribute. Instead of just saying LOCKED, you 
pass in a value:



Example #5:

<cfset sLocked = "y">
<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" LOCKED="#sLocked#">

The above example will work. If sLocked = "y" the control will be disabled, if it equals "n"
it will allow the user to changed the date.

Example #6

<cfset sReadOnly = " READONLY ">
<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" LOCKED="#sReadOnly#">

Again, the above example will work. So, to use LOCKED to disable a date input control, it must
have a value of "y" or "readonly".
The control automatically trims the LOCKED property's value.

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

Example of using the ONCHANGE attribute...

Just as a <SELECT> tag works, so does this custom tag.

Example #1:


<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" ONCHANGE="doStuff();">

In the above example, if the user changes the date, the javascript function doStuff()
is called. The programmer will have to make sure the function doStuff() is available to run of course!

Example #2:

<CF_CT_DATE_INPUT NAME="sample_fld" VALUE="11/04/2004" ONCHANGE="alert('The value of this date is:'+this.value);">

The above example display a message box showing the new value of the date control. Notice how you can use the 
javascript object "this" in your code!

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


