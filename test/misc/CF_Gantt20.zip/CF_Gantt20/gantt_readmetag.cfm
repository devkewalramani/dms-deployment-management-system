<cf_gantt showAssignedTo="yes" showDuration="yes">
	<cf_ganttitem name="Plan CF_Gantt 2.0" startdate="10/11/05" enddate="10/15/05">
	<cf_ganttitem name="Release custom tag beta" startdate="10/14/05" enddate="10/17/05" complete="0.66" color="91DBFF">
	<cf_ganttitem name="Integrate comments" startdate="10/21/05" enddate="11/25/05" color="FF0000" complete="0.70" >
	<cf_ganttgroup name="World Domination" assignedTo="SG"> 
		<cf_ganttitem name="Take over the world" startdate="10/15/05" enddate="10/18/05" complete="25%">
		<cf_ganttitem name="Create mind control mechanism" startdate="10/19/05" enddate="11/17/05" href="http://www.shlomygantz.com" complete=100>
		<cf_ganttgroup name="Testing"> 
			<cf_ganttitem name="Test mind control on the innocent" startdate="10/6/05" milestone="yes">
			<cf_ganttitem name="Integrate results into report" startdate="10/7/05" enddate="10/15/05" color="652322" id="5">
			<cf_ganttitem name="Follow up" startdate="10/8/05" enddate="10/10/05" id="1" >
			<cf_ganttitem name="Follow up 2" startdate="10/12/05" enddate="10/13/05" id="2" dependencies="1">
			<cf_ganttitem name="Follow up 3" startdate="10/14/05" enddate="10/16/05" id="4" dependencies="1">
		</cf_ganttgroup>
		<cf_ganttitem name="Activate mind control" startdate="10/17/05" enddate="10/18/05" complete="25%" assignedTo="SG"  dependencies="1">
	</cf_ganttgroup>
	<cf_ganttgroup name="Aftermath">
		<cf_ganttitem name="Gaze into the future" startdate="10/11/05" enddate="10/13/05" color="652322" assignedTo="SG">
		<cf_ganttitem name="Discover new planets to conquer" startdate="10/12/05" enddate="10/13/05">
	</cf_ganttgroup>
	<cf_ganttitem name="Clean up room" startdate="10/12/05" enddate="10/17/05" dependencies="5">
	<cf_ganttitem name="Wash the dishes" startdate="10/11/05" enddate="10/13/05" complete="0.50" color="91DBFF">
	<cf_ganttitem name="Slowly go back to reality" startdate="10/21/05" enddate="11/24/05" color="FF0000" >
</cf_gantt>

 