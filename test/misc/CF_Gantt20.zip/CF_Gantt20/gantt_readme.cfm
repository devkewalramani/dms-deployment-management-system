<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">

<HTML>
<HEAD>
	<TITLE>ColdFusion Gantt chart custom tag - CF_GANTT</TITLE>
</HEAD>

<BODY>

<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="5"><i><b>&nbsp;&nbsp;&lt;CF_GANTT&gt;</b></i></font>
</td></tr></table>
<br>

<font face="Arial,Helvetica" size="3">&nbsp;&nbsp;Creates a basic HTML Gantt chart, with horizontal scrolling, milestones, collapse and dependencies </font><br><br>
<cfinclude template="gantt_readmetag.cfm">
<table><tr><td>
<td>

</td></tr></table>


<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;USAGE</b></i></font>
</td></tr></table>
<CFFILE action="read" file="#getdirectoryfrompath(gettemplatepath())#gantt_readmetag.cfm" variable="Fcontent">

<cfoutput>#HTMLCodeFormat(Fcontent)#</cfoutput>


</font>
<BR>
<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;ATTRIBUTES</b></i></font>
</td></tr></table>
<BR>CF_GANTT<BR>
<table border="1" cellspacing="1" cellpadding="1">
<tr>
	<td bgcolor="cccccc">ATTRIBUTE</td>
	<td bgcolor="cccccc">DESCRIPTION</td>
</tr>
<tr>
	<td>STARTDATE</td>
	<td>[OPTIONAL] [Date]Gantt start date (Default will adjust to minimum item date) </td>
</tr>
<tr>
  <td>ENDDATE</td>
  <td>[OPTIONAL] [Date] Gantt end date  (Default will adjust to maximum item date) </td>
</tr>
<tr>
  <td>WIDTH</td>
  <td>[OPTIONAL] [px] Total width of Gantt chart </td>
</tr>
<tr>
	<td>SHOWASSIGNEDTO</td>
	<td>[OPTIONAL] [Yes/No] Show assigned to column </td>
</tr>
<tr>
	<td>SHOWDURATION</td>
	<td>[OPTIONAL] [Yes/No] Show duration of task in days </td>
</tr>
<tr>
	<td>DATEFORMAT</td>
	<td>[OPTIONAL] [mask] CFML mask of dataformat (Default: mm/dd/yy)</td>
</tr>
<tr>
	<td>HSCROLL</td>
	<td>[OPTIONAL] [Yes/No] Allow horizontal scroll (Default: Yes)</td>
</tr>
<tr>
	<td>COLLAPSEABLE</td>
	<td>[OPTIONAL] [Yes/No] Allow collapsing of groups (Default: Yes)</td>
</tr>
<tr>
	<td bgcolor="#FFBBBB">RESIZEGANTTONCOLLAPSE</td>
	<td bgcolor="#FFBBBB">[OPTIONAL] [Yes/No] Resize Gantt chart when collapsing groups (beta)</td>
</tr>

</table>



<BR><BR>CF_GANTTGROUP<BR><BR>
<table border="1" cellspacing="1" cellpadding="1">
<tr>
	<td bgcolor="cccccc">ATTRIBUTE</td>
	<td bgcolor="cccccc">DESCRIPTION</td>
</tr>
<tr>
	<td>NAME</td>
	<td>[REQUIRED] Gantt group name </td>
</tr>
<tr>
  <td>ASSIGNEDTO</td>
  <td>[OPTIONAL] Name of person the item is assigned to </td>
</tr>
<tr>
	<td>HREF</td>
	<td>[OPTIONAL] Link item name to URL </td>
</tr>
</table>
<BR>
CF_GANTTITEM<BR><BR>
<table border="1" cellspacing="1" cellpadding="1">
<tr>
	<td bgcolor="cccccc">ATTRIBUTE</td>
	<td bgcolor="cccccc">DESCRIPTION</td>
</tr>
<tr>
	<td>NAME</td>
	<td>[REQUIRED] Name of task</td>
</tr>
<tr>
	<td>STARTDATE</td>
	<td>[REQUIRED] [Date]Task start date </td>
</tr>
<tr>
	<td>ENDDATE</td>
	<td>[REQUIRED] [Date]Task end date </td>
</tr>
<tr>
	<td>COLOR</td>
	<td>[OPTIONAL] [RGB]Task color </td>
</tr>
<tr>
	<td>HREF</td>
	<td>[OPTIONAL] Link item name to URL </td>
</tr>
<tr>
  <td>MILESTONE</td>
  <td>[OPTIONAL] [Yes/No]Mark as milestone (Will only work if no ENDDATE attribute has been specified) </td>
</tr>
<tr>
  <td>ASSIGNEDTO</td>
  <td>[OPTIONAL] Name of person the item is assigned to </td>
</tr>
<tr>
  <td>COMPLETE</td>
  <td>[OPTIONAL] [Number]Percent complete (examples: 25%,0.25 ...) </td>
</tr>
<tr>
  <td bgcolor="#FFBBBB">DEPENDENCIES</td>
  <td bgcolor="#FFBBBB">[OPTIONAL] [List] List of Item IDs this item depends on (beta) </td>
</tr>
<tr>
  <td bgcolor="#FFBBBB">ID</td>
  <td bgcolor="#FFBBBB">[OPTIONAL] Unique identifier for the item, is required if another item depends on this one  (beta) </td>
</tr>
</table>
<table width="100%">
  <tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;BUGS</b></i></font>
</td></tr></table>
Currently only one gantt chart is allowed per page. <BR>

<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;DOWNLOAD</b></i></font>
</td></tr></table>
<a href="../CF_Gantt20.zip">Click here</a> to download the tag<BR>
<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;Variable Returned</b></i></font>
</td></tr></table>
No variables are returned <BR>
<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;INSTALLATION</b></i></font>
</td></tr></table>
Place the file <b>gantt.cfm, ganttitem.cfm, ganttgroup.cfm</b> in your CFUSION\CUSTOM TAGS directory<br>

<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;BUGS / FEATURE REQUESTS</b></i></font>
</td></tr></table>
<a href="mailto:shlomy@bluebrick.com">shlomy@bluebrick.com</a>
<BR>
<table width="100%"><tr><td bgcolor="dddddd">
<font face="Arial,Helvetica" size="3"><i><b>&nbsp;&nbsp;EXAMPLE</b></i></font>
</td></tr></table>
<a href="http://www.shlomygantz.com/customtags">http://www.shlomyganz.com/customtags</a>

 
</BODY>
</HTML>