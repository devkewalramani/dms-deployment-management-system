
<!-- (c) copyright 2006 Orville Paul Chomer, Chomer.com -->

<html>
<head>
   <title>post1.asp - post results</title>
</head>
<body>
<h1>post1.asp - post results</h1>
<br/>
<table>
   <tr>
      <td>"dt1" value:</td>
      <td><%=Request.Form("dt1") %></td>
   </tr>
   <tr>
      <td>"dt2" value:</td>
      <td><%=Request.Form("dt2") %></td>
   </tr>
</table>
<br/>
<a href="default.asp">Back to Test Page</a>
</body>
</html>
