<!-- (c) copyright 2006 Orville Paul Chomer, Chomer.com -->

<cfoutput>
<html>
<head>
   <title>post1.cfm - post results</title>
</head>
<body>
<h1>post1.cfm - post results</h1>
<br/>
<table>
   <tr>
      <td>"dt1" value:</td>
      <td>#FORM.dt1#</td>
   </tr>
   <tr>
      <td>"dt2" value:</td>
      <td>#FORM.dt2#</td>
   </tr>   
</table>
<br/>
<a href="index.cfm">Back to Test Page</a>
</body>
</html>
</cfoutput>