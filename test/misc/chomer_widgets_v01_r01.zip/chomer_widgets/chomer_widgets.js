// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BEGIN

//    File:          "chomer_widgets.js"

//    Developer:     Orville Chomer

//    Download From: http://chomer.com/coding/js/widgets/

//    (c) Copyright 2006, Orville Paul Chomer, Chomer.com (all rights reserved)
//
//
//    WHAT THIS IS:
//    chomer_widgets.js provides javascript enabled "widgets" that you can add to your
//    web pages. Best of all, it does not depend on any server sided technology such as
//    ColdFusion or ASP. From my testing, I've determined that it works in all the latest
//    version of all the major web browsers (the only one I did not test is Safari due to
//    the fact that at the moment I don't have a Mac to test on...sorry).   :(
//
//    IMPORTANT:
//    This software is provided as Freeware.  :)
//    This file, and all its supporting files, may be distributed freely in the
//    original zip file format. All files Must be included in the distribution.
//    These files cannot be sold for money without the developer's written permission.
//    These files can be used in any commercial or non-commercial applications.
//    This block of comments is to remain intact.
//    This software is provided "As Is." No warranty is provided or implied.
//    You the developer who uses this software are responsible to test your code to
//     make sure everything works as you/your clients expect. 
//    By using this software you declare that you agree to all the terms and conditions of usage
//     of this software.
//
//    WHAT'S WITH "CHOMER" THIS AND "CHOMER" THAT?
//    Besides a slight stroking of my ego, the purpose of this is to basically create a 
//    "name space" in which you don't have to worry about coding in This file breaking code in
//    other Javascript files you are using or vice versa.
//
//    CURRENT WIDGETS:
//    =================
//      date control.          syntax in html:       <chomerdate name="sample" value="11/21/2004" />
//
//    DOCUMENTATION:
//    =================
//    See: "readme.txt" for further instructions. Also look through the examples also
//    provided in the zip file!
//
//    Best Regards,
//
//    Orville Chomer (http://chomer.com)
//
// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% END

// --------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------


//   *** GLOBAL JAVASCRIPT PAGE DECLARATIONS:

//      -------------------------------------------------------------------------
          var Q;             // global page variable for a double quote!
          var nl;            // NewLine
          var vbCRLF;        // Same as NewLine
          var chomerWidgets = new Object();   // container for about everything!
          var nKeySeq=0;     // Key Sequence
//      -------------------------------------------------------------------------



//   (JS-1)  ...must be first function!!!~~
//   +--------------------------------------------------------------------------+
//   | Works like Chr() function in BASIC!                                      |
//   | has to be declared right away (first)to prevent javascript errors...     |
//   +--------------------------------------------------------------------------+
      function Chr(n) {
         return String.fromCharCode(n);
      }  // end of function Chr()
//   ----------------------------------------------------------------------------

      // Init some "Constants:"
      Q = Chr(34);  //      A double Quote
      nl = Chr(13) + Chr(10);  // new line 
      vbCRLF = nl;
      
//   +--------------------------------------------------------------------------+
//   | ChomerWidgets properties and methods.                                    |
//   +--------------------------------------------------------------------------+
      chomerWidgets.author = "Orville Chomer";
      chomerWidgets.website = "chomer.com";
      chomerWidgets.majorVersion = 1;
      chomerWidgets.minorVersion = 0;
      chomerWidgets.allObjsIdx = new Array();
      chomerWidgets.allObjs = new Array();
      chomerWidgets.datePopupGenned = false;
      
      chomerWidgets.hideDatePopup = function() {
            document.getElementById("chomer_date_popup").style.display = "none";
         } // end of method hideDatePopup()
         
      chomerWidgets.dateButtonDown = function(btn) {
            btn.style.borderStyle = "inset";
         } // end of method dateButtonDown()
         
      chomerWidgets.datePopup = function(btn, sKey) {
            btn.style.borderStyle = "outset";
            
            // does popup box exist? No? Create it!
            if (chomerWidgets.datePopupGenned == false) {
               var elFirst = document.body.firstChild;
               var oDiv = document.createElement("span");
               document.body.insertBefore(oDiv, elFirst);
               var sBtnStyle = "font-family: Tahoma; font-size: 6pt; border: outset 2px; cursor: pointer; cursor: hand;";
               var sCenterStyle = "font-family: Tahoma; font-size: 8pt;";
               var sDayHdrStyle = "background-image: url(chomer_images/wkday.gif);font-family: Tahoma; font-size: 7pt; border: outset 1px; width: 13px; text-align: center; background-color: #F7F8DE; cursor: default;";
               var sWEDayHdrStyle = "background-image: url(chomer_images/wkend.gif); width: 13px; font-family: Tahoma; font-size: 7pt; border: outset 1px; background-color: #DFDFDF; text-align: center; cursor: default;";
               
               var s = "<div id="+Q+"chomer_date_popup"+Q+" ";
               s = s + "style="+Q;
               s = s + "background-image: url(chomer_images/cal_popup.gif); ";
               s = s + "margin-top: 0px; padding-top: 0px;";
               s = s + "display: none; position: absolute; width: 108px; height:120px; border-width: 1px; ";
               s = s + "border: solid black 1px; ";
               s = s + "background-color: white; ";
               s = s + Q;
               s = s + ">";
               s = s + "<table cellpadding="+Q+"0"+Q+" cellspacing="+Q+"0"+Q+" width="+Q+"107"+Q+">";
               s = s + " <tr>";
               s = s + "   <td><div ";
               s = s + "unselectable="+Q+"on"+Q+" ";
               s = s + "ondblclick="+Q+"chomerWidgets.prevYear()"+Q+" ";
               s = s + "onclick="+Q+"chomerWidgets.prevYear()"+Q+" ";
               s = s + "style="+Q+sBtnStyle+Q+" title="+Q+"Prev Year"+Q+">&lt;&lt</div></td>";
               s = s + "   <td><div ";
               s = s + "unselectable="+Q+"on"+Q+" ";
	       s = s + "ondblclick="+Q+"chomerWidgets.prevMonth()"+Q+" ";
               s = s + "onclick="+Q+"chomerWidgets.prevMonth()"+Q+" ";
               s = s + "style="+Q+sBtnStyle+Q+" title="+Q+"Prev Month"+Q+">&lt</div></td>";
               s = s + "   <td align="+Q+"center"+Q+" style="+Q+sCenterStyle+Q+"><span id="+Q+"chomer_date_title"+Q+">Jan 2006</span></td>";
               s = s + "   <td><div ";
               s = s + "unselectable="+Q+"on"+Q+" ";
               s = s + "ondblclick="+Q+"chomerWidgets.nextMonth()"+Q+" ";
               s = s + "onclick="+Q+"chomerWidgets.nextMonth()"+Q+" ";               
               s = s + "style="+Q+sBtnStyle+Q+">&gt</div></td>";
               s = s + "   <td><div ";
               s = s + "unselectable="+Q+"on"+Q+" ";
               s = s + "ondblclick="+Q+"chomerWidgets.nextYear()"+Q+" ";
               s = s + "onclick="+Q+"chomerWidgets.nextYear()"+Q+" ";
               s = s + " style="+Q+sBtnStyle+Q+">&gt;&gt</div></td>";
               s = s + " </tr>";
               s = s + " <tr>";
               s = s + "   <td colspan="+Q+"5"+Q+" align="+Q+"center"+Q+">";
               s = s + "   <table cellpadding="+Q+"0"+Q+" cellspacing="+Q+"0"+Q+">";
               s = s + "     <tr>";
               s = s + "        <td style="+Q+sWEDayHdrStyle+Q+">S</td>";
               s = s + "        <td style="+Q+sDayHdrStyle+Q+">M</td>";
               s = s + "        <td style="+Q+sDayHdrStyle+Q+">T</td>";
               s = s + "        <td style="+Q+sDayHdrStyle+Q+">W</td>";
               s = s + "        <td style="+Q+sDayHdrStyle+Q+">T</td>";
               s = s + "        <td style="+Q+sDayHdrStyle+Q+">F</td>";
               s = s + "        <td style="+Q+sWEDayHdrStyle+Q+">S</td>";
               s = s + "     <tr>";
               s = s + "   </table>";
               s = s + "   </td>";
               s = s + " </tr>";
               s = s + "   <td colspan="+Q+"5"+Q+"><div ";
               
               s = s + "id="+Q+"chomer_cal_body"+Q+"></div>";
               s = s + "   </td>";
               s = s + " <tr>";
               s = s + " </tr>";               
               s = s + " <tr>";
               s = s + "   <td colspan="+Q+"5"+Q+" align="+Q+"center"+Q+">";               
               s = s + "   <button ";
               s = s + " onclick="+Q+"chomerWidgets.clearDate()"+Q+" ";
               s = s + " style="+Q+"font-size: 7pt; "+Q+">Clear</button>&nbsp;";
               s = s + "   <button ";
               s = s + "onclick="+Q+"chomerWidgets.hideDatePopup()"+Q+" ";
               s = s + "style="+Q+"font-size: 7pt;"+Q+">Close</button>";
               s = s + "   </td>";
               s = s + " </tr>";
               s = s + "</table>"
               s = s + "</div>";
               oDiv.innerHTML = s;
               document.getElementById("chomer_cal_body").style.height = "65px";
               chomerWidgets.datePopupGenned = true;
            } // end if
            
            if (document.getElementById("chomer_date_popup").style.display == "none") {
               var oNode = chomerWidgets.allObjs[sKey].node;               
               chomerWidgets.currentDateControl = chomerWidgets.allObjs[sKey];
               
               
               // the date initialized here is for keeping track of the navication between
               // months and years:
               var ctrl = chomerWidgets.currentDateControl
               var dtNav = new Date();
               if (ctrl.value != "") {
                  dtNav.setMonth(ctrl.value.substr(0,2)-1);
                  dtNav.setDate(ctrl.value.substr(3,2));
                  dtNav.setFullYear(ctrl.value.substr(6,4));                    
               } // end if
               chomerWidgets.navDate = dtNav;
               
               var iLeft = 0;
               while (oNode.tagName != "BODY") {
                  iLeft += oNode.offsetLeft;
                  oNode = oNode.offsetParent;
               } // end while
               document.getElementById("chomer_date_popup").style.left = iLeft+"px";
               
               var oNode = chomerWidgets.allObjs[sKey].node;
               var iTop = 0;
               while (oNode.tagName != "BODY") {
                  iTop = iTop + oNode.offsetTop;
                  oNode = oNode.offsetParent;
               } // end while
               
               var nOffset = chomerWidgets.allObjs[sKey].node.offsetHeight;
               
               
               // "Temp" code for now for Netscape or whatever else doesn't really lik offsetHeight
               if (nOffset == 0) {
                  nOffset = 21;
               } // end if
               
               iTop = iTop + nOffset;
               var sTop = iTop+"px";

               document.getElementById("chomer_date_popup").style.top = sTop;
               
               chomerWidgets.renderPopupCalendar();
               
               document.getElementById("chomer_date_popup").style.display = "";
            } else {
               // hide the popup!
               document.getElementById("chomer_date_popup").style.display = "none";
            } // end if
         } // end of method datePopup()
         
      // ----------------------------------------     
      chomerWidgets.renderPopupCalendar = function() {
               var sNoDateStyle = "border: solid #0A4B8B 1px; font-family: Tahoma; font-size: 7pt;";
               var sUnselectedStyle = "font-family: Tahoma; font-size: 7pt; border: solid #0A4B8B 1px; color: black; width: 13px;  cursor: pointer; cursor: hand;";
               var sSelectedStyle = "font-family: Tahoma; font-size: 7pt; border: solid #0A4B8B 1px; background-color: darkblue; color: white; width: 13px; cursor: default; background-image: url(chomer_images/cal_sel.gif); ";
               
               var ctrl = chomerWidgets.currentDateControl;  // short local version
               
               // ** BUILD CALENDAR DISPLAY:
               var dtSelDate = new Date();
               
               if (ctrl.value != "") {
                  dtSelDate.setMonth(ctrl.value.substr(0,2)-1);
                  dtSelDate.setDate(ctrl.value.substr(3,2));
                  dtSelDate.setFullYear(ctrl.value.substr(6,4));                    
               } // end if
               
               var dtNav = chomerWidgets.navDate;
               
               var dtStart = new Date();
               dtStart.setMonth(dtNav.getMonth());
               dtStart.setFullYear(dtNav.getFullYear());
               dtStart.setDate(1);
               
               
               var nStartDay =dtStart.getDay();
               var totDays = 30;
               
               // figure last day of month  - O.Chomer (v1.3)  March 31, 2005
               switch (dtStart.getMonth()) {
                  case 0:   // January
                     totDays = 31;
                     break;
                  case 1:  // February
                     totDays = 29;   // days in a non-leap year.
                     // leap year??
                     var r = dtStart.getFullYear() / 4.0;
                     if (r == Math.floor(r)) {
                        totDays = 28;  // yes! its a leap year!
                     } else { 
                        var sYear = dtStart.getFullYear()+"";
                        if (sYear.substr(2,2) == "00") {
                           var r = dtStart.getFullYear() / 400.0;
                           if (r == Math.floor(r)) {
                              totDays = 28;  // yes! its a leap year!
                           } // end if
                        } // end if
                     } // end if               
                     break;
                  case 2:  // March
                     totDays = 31;
                     break;            
                  case 3:  // April
                     totDays = 30;
                     break;
                  case 4:  // May
                     totDays = 31;
                     break;                
                  case 5:  // June
                     totDays = 30;
                     break;            
                  case 6:  // July
                     totDays = 31;
                     break;             
                  case 7:  // August
                     totDays = 31;
                     break;                 
                  case 8:  // September
                     totDays = 30;
                     break;                   
                  case 9:  // October
                     totDays = 31;
                     break;               
                  case 10: // November
                     totDays = 30;
                     break;                
                  case 11: // December
                     totDays = 31;
                     break;                     
               } // end switch
               // -------------- end of figuring  last day of month -- (v1.3)
         
               // Show boxes for days before the first day of the month:
               var wkdy =0;
               var s = "<table cellpadding="+Q+"0"+Q+" cellspacing="+Q+"0"+Q+"><tr>"
     
               if (nStartDay > 0) {
                  for (n=0; n < nStartDay; n++) {
                     s = s + "<td style="+Q+sNoDateStyle+Q+">&nbsp;</td>";
                     wkdy++;
                  }  // next n
               } // end if   
               
               // Generate actual calendar days:
               for (n=1; n < totDays+1; n++) {
                  var sCurrentStyle = sUnselectedStyle;
                  var sSelDate = "";
                  var sImg = "";
                  
                  if (n== dtSelDate.getDate() && dtStart.getFullYear()== dtSelDate.getFullYear() && dtStart.getMonth()== dtSelDate.getMonth()) {
                     sCurrentStyle = sSelectedStyle;
                     sImg = "url(chomer_images/cal_sel.gif)";
                  } // end if
                               
                  var sMonth = (dtNav.getMonth() + 1) + "/";
                     
                     if (sMonth.length == 2) {
                        sMonth = "0"+sMonth;
                     } // end if
                     
                     var sDay = n + "/";
                     
                     if (sDay.length == 2) {
                        sDay = "0"+sDay;
                     } // end if         
                     
                     var sDate = sMonth + sDay + dtNav.getFullYear();
                     
                     sSelDate = " onclick="+Q;
                     sSelDate = sSelDate + "chomerWidgets.pickDate('"+sDate+"')"+Q;
                     
                  
                  s = s + "<td ";
                  s = s + "onmouseover="+Q+"this.style.backgroundImage = 'url(chomer_images/date_hover.gif)'"+Q+" ";
                  s = s + "onmouseout="+Q+"this.style.backgroundImage = '"+sImg+"'"+Q+" ";
                  s = s + sSelDate+" style="+Q+sCurrentStyle+Q+" align="+Q+"center"+Q+">";                  
                  s = s + n+"</td>";
                  wkdy++;
                  
                  if (wkdy == 7) {
                     wkdy = 0;
                     s = s + "</tr><tr>";
                  } // end if
                  
               } // next n
         
               s = s + "</tr></table>";
               document.getElementById("chomer_cal_body").innerHTML = s;   
               
               var sTitle = "";
               
               switch (dtNav.getMonth()) {
                  case 0:
                     sTitle = "Jan";
                     break;
                  case 1:
                     sTitle = "Feb";
                     break;
                  case 2:
                     sTitle = "Mar";
                     break;
                  case 3:
                     sTitle = "Apr";
                     break;
                  case 4:
                     sTitle = "May";
                     break;
                  case 5:
                     sTitle = "Jun";
                     break;
                  case 6:
                     sTitle = "Jul";
                     break;
                  case 7:
                     sTitle = "Aug";
                     break;
                  case 8:
                     sTitle = "Sep"
                     break;
                  case 9:
                     sTitle = "Oct";
                     break;
                  case 10:
                     sTitle = "Nov";
                     break;
                  case 11:
                     sTitle = "Dec";
                     break
               } // end switch
               
               sTitle = sTitle + " "+dtNav.getFullYear();
               
               document.getElementById("chomer_date_title").innerHTML = sTitle;
               
         } // end of method renderPopupCalendar()
      // ----------------------------------------       
         
      // ----------------------------------------      
      chomerWidgets.prevYear = function() {
            var dtNav = chomerWidgets.navDate;
            var nYear = dtNav.getFullYear() - 1;            
            dtNav.setFullYear(nYear);
            chomerWidgets.navDate = dtNav;
            chomerWidgets.renderPopupCalendar();
         } // end of method prevYear()
         
      // ----------------------------------------
      chomerWidgets.prevMonth = function() {
            var dtNav = chomerWidgets.navDate;
            var nMonth = dtNav.getMonth() - 1; 
            var nYear = dtNav.getFullYear();
            
            if (nMonth < 0) {
               nYear = nYear - 1;
               dtNav.setFullYear(nYear);
               nMonth = 11;
            } // end if
            
            dtNav.setMonth(nMonth);
            chomerWidgets.renderPopupCalendar();
         } // end of method prevMonth() 
         
      // ----------------------------------------
      chomerWidgets.nextYear = function() {
            var dtNav = chomerWidgets.navDate;
            var nYear = dtNav.getFullYear() + 1;            
            dtNav.setFullYear(nYear);
            chomerWidgets.navDate = dtNav;
            chomerWidgets.renderPopupCalendar();
            chomerWidgets.renderPopupCalendar();
         } // end of method nextYear() 
         
      // ----------------------------------------
      chomerWidgets.nextMonth = function() {
            var dtNav = chomerWidgets.navDate;
            var nMonth = dtNav.getMonth() + 1; 
            var nYear = dtNav.getFullYear();
            
            if (nMonth > 11) {
               nYear++;
               dtNav.setFullYear(nYear);
               nMonth = 0;
            } // end if
            
            dtNav.setMonth(nMonth);
            
            chomerWidgets.renderPopupCalendar();
         } // end of method nextMonth()         
         
      // ----------------------------------------   
      chomerWidgets.pickDate = function(sDate) {
            var ctrl = chomerWidgets.currentDateControl;  // short local version
            ctrl.value = sDate;
            ctrl.inputNode.value = sDate;
            var sName = ctrl.name;
            document.getElementById("chomerdtdsp"+sName).innerHTML = sDate;
            document.getElementById("chomer_date_popup").style.display = "none";
         } // end of method pickDate()
         
      // ----------------------------------------   
      chomerWidgets.clearDate = function(sDate) {
            var ctrl = chomerWidgets.currentDateControl;  // short local version
            ctrl.value = "";
            ctrl.inputNode.value = "";
            var sName = ctrl.name;
            document.getElementById("chomerdtdsp"+sName).innerHTML = "";
            document.getElementById("chomer_date_popup").style.display = "none";
         } // end of method pickDate()
         
         
//   +--------------------------------------------------------------------------+
//   | Create a Generic "Base" Chomer Control.                                  |
//   +--------------------------------------------------------------------------+
      function chomerCreateGenericCtrl(sControlType) {
         var objNewCtrl = new Object();
         objNewCtrl.objCat = "widget";
         objNewCtrl.objType = sControlType;
         chomerWidgets.allObjsIdx[nKeySeq] = objNewCtrl;
         nKeySeq++;
         objNewCtrl.objKey = "K"+nKeySeq;
         chomerWidgets.allObjs[objNewCtrl.objKey] = objNewCtrl;
         return objNewCtrl;
      } // end of function chomerCreateGenericCtrl()
//   ----------------------------------------------------------------------------  


//   +--------------------------------------------------------------------------+
//   | Generate HTML to make a date control.                                    |
//   +--------------------------------------------------------------------------+
      function chomer_DateAddRenderMethod(date_ctrl) {

         date_ctrl.renderWidget = function() {
            var sName = date_ctrl.name;
            var sValue = date_ctrl.value;
            
            var s = "<input type="+Q+"hidden"+Q+" id="+Q+"chomeriid"+sName+Q+" name="+Q+sName+Q+" ";
            s = s + "value="+Q+sValue+Q+" />"+nl;
            s = s + "<table cellpadding="+Q+"0"+Q+"cellspacing="+Q+"0"+Q+">";
            s = s + "<tr>";
            s = s + "<td>";
            s = s + "<div id="+Q+"chomerdtdsp"+sName+Q+" ";
            s = s + "style="+Q;
            s = s + "background-image: url(chomer_images/datebox.gif); ";
            s = s + "font-family: Tahoma; font-size: 10pt; text-align: center; ";
            s = s + "background-color: white; border: solid 1px; width: 75px; height: 20px;"+Q;
            s = s + ">"+sValue;
            s = s + "</div>";
            s = s + "</td>";
            s = s + "<td>";
            s = s + "<div ";
            s = s + "title="+Q+"click to select date"+Q+" ";
            s = s + "onmousedown="+Q+"chomerWidgets.dateButtonDown(this)"+Q+" ";                  
            s = s + "onmouseup="+Q+"chomerWidgets.datePopup(this, '"+this.objKey+"')"+Q+" ";
            s = s + "style="+Q;
            s = s + "background-image: url(chomer_images/calendar.gif); background-repeat: no-repeat; background-position: center; ";
            s = s + "border: outset 1px; width: 20px; height: 20px; background-color: "+this.buttonColor+";"+Q;            
            s = s + ">";
            s = s + "</div>";
            s = s + "</td>";
            s = s + "</tr>";
            s = s +"</table>"+nl;
                  
            date_ctrl.node.innerHTML = s;
            date_ctrl.inputNode = document.getElementById("chomeriid"+sName);
            
         } // end of renderWidget method
      } // end of function 
      
      
      
      
//   +--------------------------------------------------------------------------+
//   | Initialize all of a particular Chomer widget's tag on the web page.      |
//   +--------------------------------------------------------------------------+
      function chomer_FixTag(sTag) {
         var sWork = " "+document.body.innerHTML+" ";
         var sWrkTag = "</"+sTag+">";
         var sNew = "<"+sTag;
         var sMask = "X"+sTag;         
         
         nPos = sWork.indexOf(sWrkTag);
         
         // there are no closing tags, we must be using IE so leave:
         if (nPos == -1) {
            return false;
         } // end if
         
         // remove the closing tags as the browser saw fit to put in:
         do {     
            nPos = sWork.indexOf(sWrkTag);
            
            if (nPos > -1) {
               sWork = sWork.substr(0,nPos+1)+sWork.substr(nPos+sWrkTag.length,sWork.length-nPos);
            } // end if
         } while (nPos > -1)
         
         // make sure opening tags are all in the same case:
         do {     
            nPos = sWork.indexOf("<"+sTag.toUpperCase());
            
            if (nPos > -1) {
               sWork = sWork.substr(0,nPos)+sNew+sWork.substr(nPos+sNew.length,sWork.length-nPos);
            } // end if
         } while (nPos > -1)
         
         
         
         // now to put the closing tags where I WANT THEM!:
         var sHash = sWork;
         do {     
            nPos = sHash.indexOf("<"+sTag);
                        
            if (nPos > -1) {
               sHash = sHash.substr(0,nPos)+sMask+sHash.substr(nPos+sNew.length,sHash.length-nPos);
               
               var sCheck = sWork.substr(nPos, sWork.length-nPos);
               var nPos2 = sCheck.indexOf("/>");
               
               if (nPos2 > -1) {
                  sWork = sWork.substr(0,nPos+nPos2)+"> </"+sTag+">"+sWork.substr(nPos+nPos2+2,sWork.length-nPos);
                  sHash = sHash.substr(0,nPos+nPos2)+"> </"+sTag+">"+sHash.substr(nPos+nPos2+2,sHash.length-nPos);
               } else {
                  var nPos3 = sCheck.indexOf(">");
                  if (nPos3 > -1) {
                     sWork = sWork.substr(0,nPos+nPos3)+"> </"+sTag+">"+sWork.substr(nPos+nPos3+2,sWork.length-nPos);
                     sHash = sHash.substr(0,nPos+nPos3)+"> </"+sTag+">"+sHash.substr(nPos+nPos3+2,sHash.length-nPos);
                  } // end if
               } // end if
               
            } // end if
         } while (nPos > -1)
         
         document.body.innerHTML = sWork;
         return true;  // closing tags modified, non-IE browser
      } // end of function chomer_FixTag()
//   ----------------------------------------------------------------------------    


      
      
//   +--------------------------------------------------------------------------+
//   | Initialize all the Chomer widgets on the web page.                       |
//   +--------------------------------------------------------------------------+
      function chomer_Init_Page() {
         chomerInitControlSpots("chomerdate", "date_ctrl", "chomerdt");
         
      } // end of function chomer_renderCtrls()
//   ----------------------------------------------------------------------------


//   +--------------------------------------------------------------------------+
//   | Create ID'd span tags to place date controls in. (no closing tags)       |
//   +--------------------------------------------------------------------------+
      function chomerInitControlSpots(sTagName, sControlName, sIDPrefix) {
         var nTotal = 0;
         var sClass;
         var sOnChange;
         var nCtrl = 0;
         var ndx = 0;
                 
         if (chomer_FixTag(sTagName) == false) {
            // ***********************
            // Internet Explorer code:
            // ***********************
            
            do {
               var ctrls = document.getElementsByTagName(sTagName);
               var nTotal = ctrls.length;
               
               if (nTotal > 0) {
                  var ctrl = ctrls[0];
                  var n=0;
                  sClass = "";
                  sOnChange = "";
                  sName = "na";
                  sValue = "";     
                  for (n=0;n<ctrl.attributes.length;n++) {
                     if (ctrl.attributes[n].value != null) {
                        switch (ctrl.attributes[n].name.toLowerCase()){
                           case "name":
                              sName = ctrl.attributes[n].value;
                              break;     
                           case "value":
                              sValue = ctrl.attributes[n].value;
                              break;                             
                           case "class":
                              sClass = ctrl.attributes[n].value;
                              break;
                           case "onchange":
                              sOnChange = ctrl.attributes[n].value;
                              break;
                        } // end switch
                     } // end if
                  } // next n               
               
                  var new_ctrl = chomerCreateGenericCtrl(sControlName);
                  new_ctrl.name = sName;
                  new_ctrl.value = sValue;
                  new_ctrl.className = sClass;
                  new_ctrl.onchange = sOnChange;
                  
                  var sNewContainer = "<span id="+Q+sIDPrefix+sName+Q+">loading...</span>";

                  ctrl.outerHTML = sNewContainer;  
                  new_ctrl.node = document.getElementById(sIDPrefix+sName);
                  
                  
                  switch (sTagName) {
                     case "chomerdate":
                        chomer_DateAddRenderMethod(new_ctrl);
                        break;
                  } // end switch
                  
                  new_ctrl.renderWidget();                  
               } // end if (nTotal > 0)
               
            } while (nTotal > 0)
            
         } else {
            // ***************************
            // non Internet Explorer code:
            // ***************************
            var ctrls = document.getElementsByTagName(sTagName);
            nTotal = ctrls.length;
            
            if (nTotal > 0) {
               for (ndx=0; ndx < nTotal; ndx++) {
                  var ctrl = ctrls[ndx];
                  var n=0;
                  sClass = "";
                  sOnChange = "";
                  sName = "na";
                  sValue = "";
               
                  for (n=0;n<ctrl.attributes.length;n++) {
                     if (ctrl.attributes[n].value != null) {
                        switch (ctrl.attributes[n].name.toLowerCase()){
                           case "name":
                              sName = ctrl.attributes[n].value;
                              break;     
                           case "value":
                              sValue = ctrl.attributes[n].value;
                              break;                             
                           case "class":
                              sClass = ctrl.attributes[n].value;
                              break;
                           case "onchange":
                              sOnChange = ctrl.attributes[n].value;
                              break;
                        } // end switch
                     } // end if
                  } // next n
               
               
                  var new_ctrl = chomerCreateGenericCtrl(sControlName);
                  new_ctrl.name = sName;
                  new_ctrl.value = sValue;
                  new_ctrl.className = sClass;
                  new_ctrl.onchange = sOnChange;
          
                  var sNewContainer = "<span id="+Q+sIDPrefix+sName+Q+">loading...</span>";

                  ctrl.innerHTML = sNewContainer;

                  new_ctrl.node = document.getElementById(sIDPrefix+sName);
               
                  switch (sTagName) {
                     case "chomerdate":
                        chomer_DateAddRenderMethod(new_ctrl);
                        break;
                  } // end switch
                  
                  new_ctrl.renderWidget();
               } // next ndx       
            } // end if (nTotal > 0) 
         } // end if (chomer_FixTag(sTagName) == false)         
         
      } // end of function chomerInitDateControls()
//   ----------------------------------------------------------------------------    


