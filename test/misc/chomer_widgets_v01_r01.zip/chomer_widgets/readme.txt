***************************************************************
          CHOMER WIDGETS

***************************************************************

    (c) copyright 2006, Orville Paul Chomer, Chomer.com (All Rights Reserved)

***************************************************************

    CONTENTS:

         1) PURPOSE

         2) TAG CONCEPT

         3) USAGE

         4) EXAMPLES

================================================================

 1) PURPOSE

        If you use the ColdFusion application server, and needed
        a date control for your web page, you might have stumbled
        upon the custom tag I wrote for just such a purpose. Yes,
        it would allow you to place nifty date controls on your
        ColdFusion web pages! There were a few problems though:
             1) Your server had to run ColdFusion.
             2) I only designed it to work in Internet Explorer.

        Well, for some time now, I've had the idea to write a 
        solution that would work in any browser and not be 
        dependant on any specific web application server such as
        ColdFusion. This started and stopped. But eventually,
        it's here! And it's easy to use.

        You can add one or more date controls to any web page
        and they basically work like a standard <INPUT> tag in
        HTML! So, if you understand the <INPUT> tag, you can use
        this date control!

        Eventually, the date control will (hopefully) be joined by
        other useful controls to add to your toolchest.



2) TAG CONCEPT
          
        ColdFusion has what is known as "custom tags." I thought to 
        my self, "wouldn't it be nice if I could add my own tags to 
        my html without needing any special application servers?"
        In a moment of serindipedy, I hit on how to do it. After a few
        hours of work I got it to work. In the future I am planning
        on writing an article on how to implement your own tags on
        your web pages to roll your own "widgets!" Basically, there
        is a block of code near the top of the page that refers to
        the javascript file being used, then there are the new tags
        interspersed throughout the page, and finally, one call to a 
        Javascript function at the end of the page. It's simple and 
        it works!


3) USAGE

        Now for the important part, How do you use this date control on
        your own pages?

        1) Copy the javascript file and the folder containing all the 
           images to your server.

        2) Make a Web page:

              a) In the top of the page refer to the javascript file like thus:

                  <script language="javascript" type="text/javascript" src="chomer_widgets.js"></script>



              b) In the body of page interspersed with the rest of your HTML, use the <chomerdate> tag:

                  <chomerdate name="my_date" value="11/23/2006" />

                  * Note that the value attribute is optional.
                  * If you give the value attribute a value it must have a date formatted: MM/DD/YYYY.
                  * The forward slash at the end of the TAG is REQUIRED! This even goes for a page
                    that is not set up to be XHTML Strict. leaving it out will cause your page to choke!



              c) At the end of the page, just before the closing </body> tag, you need to call one 
                 Javascript function:

                  <!-- piece of Javascript code that needs to be at the end of the page: -->
                  <script language="javascript" type="text/javascript">
                     chomer_Init_Page();
                  </script>         

                 You could alternately call this function in the onload event of the body tag.


         That's about it! When your form posts, the date value will post with the just like the input 
         value posts with a standard <input> tag.

         The control lacks bells and whistles. But it functions well. We'll see about adding some
         extra features later!


4) EXAMPLES

         In the zip file that this file came in, are provided some examples for you to look at.
         * All the files that end with *.cfm are ColdFusion examples.
         * All the files that end with *.asp are Active Server Pages examples.
         * All the files that end with *.htm are plain HTML examples (no server sided scripting).

         At very least, you should be able to play around with the HTML examples if you lack a web
         server to test on. The actual code for the date controls is server independent. But I 
         show you some simple server-sided code showing how to process the posted data and how easy
         it is.

         SIMPLE EXAMPLE:
         -----------------------------------------------------------------------------------------
             <html>
               <head>
                    <script language="javascript" type="text/javascript" src="chomer_widgets.js"></script>
               </head>
               <body>
                  <form name="my_form" method="post" action="process_results.php">
                     Enter Sample Date:   
                     <chomerdate name="sample_date" value="01/01/2004" /> 
                     
                  </form>

                  <!-- piece of Javascript code that needs to be at the end of the page: -->
                  <script language="javascript" type="text/javascript">
                     chomer_Init_Page();
                  </script> 
               </body>
             </html>
 
         -----------------------------------------------------------------------------------------
           


FINAL COMMENTS
         I hope you like this widget and find it useful. I hope to periodically update the widget,
         samples, and it's documentation. Remember, its freeware. It's provided "As is." 
         There is No Warranty/Garantee of any kind. You must test your code and make sure it works.
         See the comments at the top of the js file for more information.

Best Regards,

Orville Chomer (http://chomer.com)



 
         
