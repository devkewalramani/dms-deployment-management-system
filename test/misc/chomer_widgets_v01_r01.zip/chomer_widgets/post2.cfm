<!-- (c) copyright 2006 Orville Paul Chomer, Chomer.com -->

<cfoutput>
<html>
<head>
   <title>post2.cfm - post results</title>
</head>
<body>
<h1>post2.cfm - post results</h1>
<br/>
<table>
   <tr>
      <td>"first_name" value:</td>
      <td>#FORM.first_name#</td>
   </tr>
   <tr>
      <td>"last_name" value:</td>
      <td>#FORM.last_name#</td>
   </tr>  
   <tr>
      <td>"color" value:</td>
      <td>#FORM.color#</td>
   </tr>    
   
   <tr>
      <td>"create_date" value:</td>
      <td>#FORM.create_date#</td>
   </tr>    
</table>
<br/>
<a href="index.cfm">Back to Test Page</a>
</body>
</html>
</cfoutput>