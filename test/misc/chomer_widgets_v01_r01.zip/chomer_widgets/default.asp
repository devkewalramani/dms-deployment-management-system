
<!-- (c) copyright 2006 Orville Paul Chomer, Chomer.com -->

<html>
<head>
   <title>Chomer.com - Javascript Widget Test Page (ASP Example)</title>
   <script language="javascript" type="text/javascript" src="chomer_widgets.js"></script>
</head>
<body bgcolor="silver">
<h1>Chomer.com - Javascript Widget Test Page (ASP Example)</h1>
<form name="test1" action="post1.asp" method="post">
<fieldset style="width: 400px;">
<table>
<tr>
   <td nowrap>This is a date:</td>
   <td><chomerdate name="dt1" value="01/01/2006" onchange="alert('hi')"/></td>
   <td nowrap>This is another date:</td>
   <td><chomerdate name="dt2" /></td>
   <td><input type="submit" value="Submit" /></td>
</tr>
</table>
</fieldset>
</form>
<p>
This is a sample page to test the operation to the Chomer Javascript date control.<br/><br/>
Try different scrolling of different elements on this page, and then check to make sure
that the positioning of popups is correct.
</p>

<table>
   <tr valign="top">
      <td width="45%"><b>Widget Building</b></br>I think that many widgets could be added to a regular web page to add
      all sorts of functionality without the need for ActiveX controls, Flash, Java Applets and
      the like. Using imagination, knowledge of DHTML, and some sweat-equity, one could
      (via the use of Javascript) roll their own widgets which would be more than adiquate for
      the job. This page demonstrates this possibility by allowing you the user to try out
      widgets I have constructed. Currently, the first widget is a date control.
      This control allows the user to select a date from a popup calendar. I have plans to eventually
      upgrade the date control with more functionality, and, provide additional widgets!
         <br/><br/>
         <form name="test2" action="post2.asp" method="post">
            <table>
               <tr>
                  <td nowrap>First Name:</td>
                  <td><input name="first_name" value="Joe" /></td>
               </tr>
               <tr>
                  <td nowrap>Last Name:</td>
                  <td><input name="last_name" value="Programmer" /></td>
               </tr>
               <tr>
                  <td>Color:</td>
                  <td><input name="color" value="red" type="radio" /> Red
                  <input name="color" value="yellow" type="radio" /> Yellow
                  <input name="color" value="blue" type="radio" checked /> Blue
                  <input name="color" value="green" type="radio" /> Green
                  </td>
               </tr>
               <tr>
                  <td><input name="active" value="y" type="checkbox" checked/> Active</td>
                  <td><input name="special" value="y" type="checkbox" /> Special</td>
               </tr>
               <tr>
                  <td nowrap>Create Date</td>
                  <td><chomerdate name="create_date" /></td>
               </tr>
               <tr>

                  <td colspan="2" align="center"><input type="submit" value="New User" /></td>
               </tr>
            </table>
         </form>
      </td>
      <td>&nbsp;</td>
      <td width="45%"><b>Customized Tags</b><br/>
      To simplify the use of a widget, I thought: "Wouldn't it be nice to be able to use custom widgets/controls
      the same way you would use a build in web control. e.g.: the &lt;input /&gt; tag.<br/><br/>
      Well, lightning struck and I got this idea see... where a developer using one of the new widgets would
      need to use minimal Javascript and use <i>new</i> tags (just the same way one would use a regular HTML tag).
      I experimented abit and achieved success! And in all the lastest versions of the major web browsers.
      <br/><br/>The new date control widget is: <b>&lt;chomerdate /&gt;</b>. Notice that below is filled in
      with the Server's System Date:<br/>

      <%
         sMonth = Month(Now()) & "/"

         If Len(sMonth) = 2 Then
            sMonth = "0" & sMonth
         End If

         sDay = Day(Now()) & "/"

         If Len(sDay) = 2 Then
            sDay = "0" & sDay
         End If

         sDate = sMonth & sDay & Year(Now())
      %>
      <chomerdate name="sample_date" value="<%=sDate %>" /> Try using it basically the same way as an
      ordinary &lt;input&gt; tag!</td>
   </tr>
</table>
   <br/>&nbsp;
   <br/>&nbsp;
   <br/>&nbsp;
   <br/>&nbsp;

   <br/>&nbsp;
   <br/>&nbsp;

<!-- piece of Javascript code that needs to be at the end of the page: -->
   <script language="javascript" type="text/javascript">
           chomer_Init_Page();
   </script>
</body>
</html>
